import { getAuthUser } from "@/lib/session";
import NavBar from "./NavBar";

export default async function SiteHeader() {
  let user = null;
  try {
    user = await getAuthUser();
  } catch {
    user = null;
  }

  return <NavBar user={user} />;
}

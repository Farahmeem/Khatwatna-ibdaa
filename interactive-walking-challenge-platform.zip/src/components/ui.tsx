import type { ReactNode } from "react";
import { DOMAIN_ICONS, DOMAIN_LABELS, MEDALS, type Domain } from "@/lib/constants";
import { clampPercent, formatNumber, formatPercent } from "@/lib/format";

export function ProgressBar({
  value,
  gold = false,
  className = "",
  height = "h-3",
}: {
  value: number;
  gold?: boolean;
  className?: string;
  height?: string;
}) {
  return (
    <div className={`progress-track ${height} ${className}`}>
      <div
        className={`progress-fill ${gold ? "progress-fill-gold" : ""}`}
        style={{ width: `${clampPercent(value)}%` }}
      />
    </div>
  );
}

export function StatTile({
  icon,
  label,
  value,
  hint,
  accent = "brand",
}: {
  icon: string;
  label: string;
  value: ReactNode;
  hint?: string;
  accent?: "brand" | "gold" | "sky" | "violet";
}) {
  const accents: Record<string, string> = {
    brand: "from-brand-50 to-white border-brand-100 text-brand-800",
    gold: "from-gold-50 to-white border-gold-200 text-gold-600",
    sky: "from-sky-50 to-white border-sky-100 text-sky-700",
    violet: "from-violet-50 to-white border-violet-100 text-violet-700",
  };

  return (
    <div
      className={`rounded-2xl border bg-gradient-to-br p-4 shadow-sm ${accents[accent]}`}
    >
      <div className="flex items-center justify-between gap-2">
        <span className="text-xs font-bold text-ink-500">{label}</span>
        <span className="grid h-8 w-8 place-items-center rounded-xl bg-white/80 text-base shadow-sm">
          {icon}
        </span>
      </div>
      <p className="mt-2 text-2xl font-extrabold tracking-tight">{value}</p>
      {hint ? <p className="mt-0.5 text-[11px] font-medium text-ink-500">{hint}</p> : null}
    </div>
  );
}

export function SectionHeading({
  eyebrow,
  title,
  description,
  action,
}: {
  eyebrow?: string;
  title: string;
  description?: string;
  action?: ReactNode;
}) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
      <div>
        {eyebrow ? (
          <span className="chip chip-gold mb-2">{eyebrow}</span>
        ) : null}
        <h2 className="text-2xl font-extrabold text-brand-900 sm:text-3xl">{title}</h2>
        {description ? (
          <p className="mt-1 max-w-2xl text-sm text-ink-500">{description}</p>
        ) : null}
      </div>
      {action}
    </div>
  );
}

export function RankBadge({ rank }: { rank: number }) {
  if (rank <= 3) return <span className="text-xl">{MEDALS[rank - 1]}</span>;
  return (
    <span className="inline-grid h-7 w-7 place-items-center rounded-full bg-brand-50 text-xs font-extrabold text-brand-700">
      {rank}
    </span>
  );
}

export function DomainBadge({ domain }: { domain: Domain }) {
  return (
    <span className="chip">
      <span>{DOMAIN_ICONS[domain]}</span>
      {DOMAIN_LABELS[domain]}
    </span>
  );
}

export function StepValue({ steps }: { steps: number }) {
  return (
    <span className="font-extrabold text-brand-800">
      {formatNumber(steps)} <span className="text-xs font-bold text-ink-500">خطوة</span>
    </span>
  );
}

export function PercentPill({ value, gold = false }: { value: number; gold?: boolean }) {
  return <span className={`chip ${gold ? "chip-gold" : ""}`}>{formatPercent(value, 1)}</span>;
}

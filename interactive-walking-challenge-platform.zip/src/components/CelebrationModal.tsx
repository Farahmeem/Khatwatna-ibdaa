"use client";

import { CELEBRATION_PHRASES } from "@/lib/content";
import { formatNumber } from "@/lib/format";

type Props = {
  name: string;
  steps: number;
  message: string;
  onClose: () => void;
};

const STAR_ICONS = ["⭐", "✨", "🌟", "💫", "🏅", "🎉", "🌿", "⭐", "✨", "🌟"];

export default function CelebrationModal({ name, steps, message, onClose }: Props) {
  const phrases = [
    message,
    ...CELEBRATION_PHRASES.filter((phrase) => phrase !== message).slice(0, 2),
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-brand-900/70 px-4 py-6 backdrop-blur-sm">
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        {Array.from({ length: 28 }).map((_, index) => (
          <span
            key={index}
            className="confetti-star"
            style={{
              left: `${(index * 37) % 100}%`,
              animationDelay: `${(index % 9) * 0.42}s`,
              animationDuration: `${4.6 + (index % 5) * 0.7}s`,
              ["--drift" as string]: `${(index % 2 === 0 ? 1 : -1) * (16 + (index % 7) * 8)}px`,
            }}
          >
            {STAR_ICONS[index % STAR_ICONS.length]}
          </span>
        ))}
      </div>

      <div className="animate-pop relative w-full max-w-lg overflow-hidden rounded-3xl border border-gold-200 bg-white p-6 text-center shadow-2xl sm:p-8">
        <div className="absolute inset-x-0 top-0 h-1.5 bg-gradient-to-l from-gold-300 via-brand-400 to-gold-300" />
        <div className="mx-auto grid h-24 w-24 place-items-center rounded-full bg-gradient-to-br from-gold-200 to-gold-400 text-5xl shadow-xl medal-ring">
          🏆
        </div>

        <p className="mt-4 text-xs font-extrabold uppercase tracking-widest text-gold-600">
          إنجاز اليوم
        </p>
        <h2 className="mt-1 text-2xl font-extrabold text-brand-900 sm:text-3xl">
          أحسنتِ يا {name}!
        </h2>

        <p className="mt-3 rounded-2xl bg-brand-50 px-4 py-3 text-sm font-bold text-brand-800">
          {formatNumber(steps)} خطوة اليوم — هدف الـ 10,000 خطوة تحقّق 🎯
        </p>

        <ul className="mt-4 space-y-2 text-right">
          {phrases.map((phrase) => (
            <li
              key={phrase}
              className="flex items-start gap-2 rounded-xl border border-gold-100 bg-gold-50/70 px-3 py-2 text-sm font-bold leading-6 text-ink-700"
            >
              <span className="text-gold-500">✦</span>
              <span>{phrase}</span>
            </li>
          ))}
        </ul>

        <div className="mt-5 flex flex-col gap-2 sm:flex-row">
          <button type="button" onClick={onClose} className="btn btn-primary flex-1">
            متابعة التحدي 🌿
          </button>
          <span className="chip chip-gold self-center justify-center sm:self-auto">
            ⭐ نقاطكِ المعرفية منفصلة وتبقى محفوظة
          </span>
        </div>
      </div>
    </div>
  );
}

"use client";

import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import { MEDALS } from "@/lib/constants";
import { clampPercent, formatDateTime, formatNumber, formatPercent } from "@/lib/format";
import type { LeaderboardPayload } from "@/lib/types";
import { ProgressBar } from "./ui";

type SortKey = "steps" | "points";

export default function LeaderboardClient({
  initial,
  currentParticipantId,
}: {
  initial: LeaderboardPayload;
  currentParticipantId: string | null;
}) {
  const [data, setData] = useState<LeaderboardPayload>(initial);
  const [sortBy, setSortBy] = useState<SortKey>("steps");
  const [loading, setLoading] = useState(false);

  const reload = useCallback(async (showLoader = false) => {
    if (showLoader) setLoading(true);
    try {
      const response = await fetch("/api/leaderboard", { cache: "no-store" });
      if (response.ok) {
        setData((await response.json()) as LeaderboardPayload);
      }
    } catch {
      // نحافظ على آخر بيانات معروضة
    } finally {
      if (showLoader) setLoading(false);
    }
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      void reload(false);
    }, 10_000);
    return () => clearInterval(timer);
  }, [reload]);

  const rows = [...data.rows].sort((a, b) =>
    sortBy === "steps" ? a.rankSteps - b.rankSteps : a.rankPoints - b.rankPoints,
  );
  const podium = [...data.rows].sort((a, b) =>
    sortBy === "steps" ? a.rankSteps - b.rankSteps : a.rankPoints - b.rankPoints,
  );
  const top = [podium[1], podium[0], podium[2]].filter(Boolean);

  return (
    <div className="mx-auto max-w-6xl px-4 py-8">
      <section className="card relative overflow-hidden p-6 sm:p-8">
        <div className="pattern-dots absolute inset-0 opacity-30" />
        <div className="relative flex flex-wrap items-end justify-between gap-4">
          <div>
            <span className="chip chip-gold">🏁 لوحة مباشرة</span>
            <h1 className="mt-2 text-3xl font-extrabold text-brand-900 sm:text-4xl">
              لوحة المتصدرات
            </h1>
            <p className="mt-2 max-w-xl text-sm leading-6 text-ink-500">
              ترتيب مباشر للمشاركات في الأسبوع {data.week.weekNumber} — يمكنكِ التبديل بين ترتيب
              الخطوات وترتيب نقاط التحديات المعرفية. يتم التحديث تلقائياً كل 10 ثوانٍ ⚡
            </p>
          </div>
          <div className="flex flex-col items-start gap-2 sm:items-end">
            <div className="flex gap-2 rounded-2xl bg-brand-50 p-1">
              <button
                type="button"
                onClick={() => setSortBy("steps")}
                className={`rounded-xl px-3 py-2 text-xs font-extrabold transition ${
                  sortBy === "steps" ? "bg-white text-brand-800 shadow-sm" : "text-ink-500"
                }`}
              >
                👟 ترتيب الخطوات
              </button>
              <button
                type="button"
                onClick={() => setSortBy("points")}
                className={`rounded-xl px-3 py-2 text-xs font-extrabold transition ${
                  sortBy === "points" ? "bg-white text-gold-600 shadow-sm" : "text-ink-500"
                }`}
              >
                🧠 ترتيب المعرفة
              </button>
            </div>
            <div className="flex items-center gap-2 text-[11px] font-bold text-ink-500">
              <span className="flex items-center gap-1.5 rounded-full bg-white px-3 py-1">
                <span className="relative flex h-2 w-2">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-brand-400 opacity-75" />
                  <span className="relative inline-flex h-2 w-2 rounded-full bg-brand-500" />
                </span>
                تحديث مباشر
              </span>
              <span>آخر تحديث: {formatDateTime(data.generatedAt)}</span>
              <button
                type="button"
                onClick={() => void reload(true)}
                className="btn btn-soft !px-2.5 !py-1 !text-[11px]"
                disabled={loading}
              >
                {loading ? "..." : "🔄"}
              </button>
            </div>
          </div>
        </div>

        <div className="relative mt-6 grid grid-cols-2 gap-2 sm:grid-cols-4">
          {[
            { label: "المشاركات", value: formatNumber(data.totals.participants), icon: "👥" },
            { label: "إجمالي الخطوات", value: formatNumber(data.totals.steps), icon: "👟" },
            {
              label: "الكيلومترات",
              value: formatNumber(data.totals.km),
              icon: "📍",
            },
            { label: "نقاط المعرفة", value: formatNumber(data.totals.points), icon: "🧠" },
          ].map((item) => (
            <div
              key={item.label}
              className="rounded-2xl border border-brand-100 bg-white/80 px-3 py-2.5 text-center"
            >
              <p className="text-[10px] font-bold text-ink-500">
                {item.icon} {item.label}
              </p>
              <p className="text-lg font-extrabold text-brand-900">{item.value}</p>
            </div>
          ))}
        </div>
      </section>

      {data.rows.length === 0 ? (
        <div className="card mt-6 p-10 text-center">
          <p className="text-4xl">🌱</p>
          <h2 className="mt-3 text-xl font-extrabold text-brand-900">لا توجد مشاركات بعد</h2>
          <p className="mt-1 text-sm text-ink-500">
            كوني أول من يبدأ التحدي وشاركي الرابط مع صديقاتك.
          </p>
          <Link href="/login" className="btn btn-primary mt-4">
            ابدئي التحدي
          </Link>
        </div>
      ) : (
        <>
          {/* منصة التتويج */}
          <section className="mt-6 grid items-end gap-3 sm:grid-cols-3">
            {top.map((row) => {
              const actualRank =
                sortBy === "steps" ? row.rankSteps : row.rankPoints;
              const medal = MEDALS[actualRank - 1] ?? "🎖️";
              const sizes = actualRank === 1 ? "pt-3 sm:pb-6" : "pt-6";
              return (
                <div
                  key={row.id}
                  className={`card relative overflow-hidden p-4 text-center ${sizes}`}
                >
                  {actualRank === 1 ? (
                    <span className="absolute right-3 top-3 text-xs font-extrabold text-gold-500">
                      المتصدرة 👑
                    </span>
                  ) : null}
                  <div
                    className={`mx-auto grid place-items-center rounded-full bg-gradient-to-br ${
                      actualRank === 1
                        ? "h-20 w-20 from-gold-200 to-gold-400 text-4xl medal-ring"
                        : "h-16 w-16 from-brand-100 to-brand-200 text-3xl"
                    }`}
                  >
                    {medal}
                  </div>
                  <p className="mt-2 text-lg font-extrabold text-brand-900">{row.avatar} {row.name}</p>
                  <p className="text-xs font-bold text-ink-500">
                    {sortBy === "steps"
                      ? `${formatNumber(row.totalSteps)} خطوة`
                      : `${formatNumber(row.points)} نقطة معرفية`}
                  </p>
                  <div className="mt-2">
                    <ProgressBar
                      value={sortBy === "steps" ? row.percent : clampPercent((row.points / 70) * 100)}
                      gold={actualRank === 1}
                      height="h-2"
                    />
                  </div>
                  <div className="mt-2 flex flex-wrap justify-center gap-1">
                    <span className="chip">{formatPercent(row.percent, 1)} إنجاز</span>
                    <span className="chip chip-gold">✅ {row.completedDays} أيام</span>
                  </div>
                </div>
              );
            })}
          </section>

          {/* الجدول الكامل */}
          <section className="card mt-6 overflow-hidden">
            <div className="scroll-x">
              <table className="w-full min-w-[720px] border-collapse text-right text-sm">
                <thead>
                  <tr className="bg-brand-50/80 text-xs text-brand-800">
                    <th className="px-3 py-3 font-extrabold">المركز</th>
                    <th className="px-3 py-3 font-extrabold">المشاركة</th>
                    <th className="px-3 py-3 font-extrabold">إجمالي الخطوات</th>
                    <th className="px-3 py-3 font-extrabold">نسبة الإنجاز</th>
                    <th className="px-3 py-3 font-extrabold">الأيام المكتملة</th>
                    <th className="px-3 py-3 font-extrabold">نقاط المعرفة</th>
                    <th className="px-3 py-3 font-extrabold">الكيلومترات</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((row) => {
                    const rank = sortBy === "steps" ? row.rankSteps : row.rankPoints;
                    const isMe = currentParticipantId === row.id;
                    return (
                      <tr
                        key={row.id}
                        className={`border-t border-brand-50 transition ${
                          isMe ? "bg-gold-50/70" : "hover:bg-brand-50/40"
                        }`}
                      >
                        <td className="px-3 py-3">
                          <div className="flex items-center gap-1.5 font-extrabold text-brand-900">
                            {rank <= 3 ? (
                              <span className="text-xl">{MEDALS[rank - 1]}</span>
                            ) : (
                              <span className="grid h-7 w-7 place-items-center rounded-full bg-brand-50 text-xs text-brand-700">
                                {rank}
                              </span>
                            )}
                          </div>
                        </td>
                        <td className="px-3 py-3">
                          <div className="flex items-center gap-2">
                            <span className="grid h-8 w-8 place-items-center rounded-full bg-white text-base shadow-sm">
                              {row.avatar}
                            </span>
                            <div>
                              <p className="font-extrabold text-brand-900">
                                {row.name}{" "}
                                {isMe ? <span className="chip mr-1">أنتِ</span> : null}
                              </p>
                              <p className="text-[10px] font-medium text-ink-500">
                                اليوم: {formatNumber(row.todaySteps)} خطوة
                              </p>
                            </div>
                          </div>
                        </td>
                        <td className="px-3 py-3 font-extrabold text-brand-800">
                          {formatNumber(row.totalSteps)}
                        </td>
                        <td className="px-3 py-3">
                          <div className="flex items-center gap-2">
                            <div className="w-24">
                              <ProgressBar value={row.percent} height="h-1.5" />
                            </div>
                            <span className="text-xs font-bold text-ink-500">
                              {formatPercent(row.percent, 1)}
                            </span>
                          </div>
                        </td>
                        <td className="px-3 py-3">
                          <span className="chip">✅ {row.completedDays}/7</span>
                        </td>
                        <td className="px-3 py-3">
                          <span className="font-extrabold text-gold-600">
                            {formatNumber(row.points)}
                          </span>{" "}
                          <span className="text-[10px] font-bold text-ink-500">
                            ({row.correctAnswers} صحيحة)
                          </span>
                        </td>
                        <td className="px-3 py-3 font-bold text-ink-500">
                          {formatNumber(row.km)} كم
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </section>

          <p className="mt-3 text-center text-xs font-medium text-ink-500">
            🧠 نقاط التحديات المعرفية محسوبة بشكل مستقل: عدد الإجابات الصحيحة × 10 نقاط.
          </p>
        </>
      )}
    </div>
  );
}



"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useState, useTransition } from "react";

type Props = {
  user: {
    role: "participant" | "admin";
    name: string;
    avatar: string;
    participantId: string | null;
  } | null;
};

const adminLinks = [
  { href: "/", label: "الرئيسية" },
  { href: "/leaderboard", label: "لوحة المتصدرات" },
  { href: "/admin", label: "لوحة المشرفة" },
];

const guestLinks = [
  { href: "/", label: "الرئيسية" },
  { href: "/leaderboard", label: "لوحة المتصدرات" },
  { href: "/login", label: "الدخول" },
];

const participantLinks = [
  { href: "/", label: "الرئيسية" },
  { href: "/dashboard", label: "تحديي اليومي" },
  { href: "/achievements", label: "إنجازاتي" },
  { href: "/leaderboard", label: "لوحة المتصدرات" },
];

export default function NavBar({ user }: Props) {
  const pathname = usePathname();
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [pending, startTransition] = useTransition();

  const links = !user ? guestLinks : user.role === "admin" ? adminLinks : participantLinks;

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST" });
    startTransition(() => {
      router.push("/");
      router.refresh();
    });
  }

  return (
    <header className="no-print sticky top-0 z-40 border-b border-brand-100/80 bg-white/85 backdrop-blur-md">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-3 px-4 py-3">
        <Link href="/" className="group flex items-center gap-3">
          <span className="relative grid h-11 w-11 place-items-center rounded-2xl bg-gradient-to-br from-brand-500 to-brand-800 text-xl text-white shadow-lg shadow-brand-800/25">
            👟
            <span className="absolute -left-1 -top-1 text-xs">✨</span>
          </span>
          <span className="leading-tight">
            <span className="block text-lg font-extrabold tracking-tight text-brand-900">
              خطواتنا إبداع
            </span>
            <span className="block text-[11px] font-medium text-ink-500">
              خطوة اليوم.. إنجاز الغد
            </span>
          </span>
        </Link>

        <nav className="hidden items-center gap-1 md:flex">
          {links.map((link) => {
            const active =
              link.href === "/" ? pathname === "/" : pathname.startsWith(link.href);
            return (
              <Link
                key={link.href}
                href={link.href}
                className={`rounded-full px-3.5 py-2 text-sm font-bold transition ${
                  active
                    ? "bg-brand-50 text-brand-800 shadow-inner"
                    : "text-ink-500 hover:bg-brand-50/70 hover:text-brand-800"
                }`}
              >
                {link.label}
              </Link>
            );
          })}
        </nav>

        <div className="flex items-center gap-2">
          {user ? (
            <div className="flex items-center gap-2">
              <span className="hidden items-center gap-2 rounded-full border border-brand-100 bg-white px-3 py-1.5 sm:flex">
                <span className="grid h-7 w-7 place-items-center rounded-full bg-brand-50 text-base">
                  {user.avatar}
                </span>
                <span className="max-w-[9rem] truncate text-xs font-bold text-brand-900">
                  {user.name}
                </span>
              </span>
              <button
                type="button"
                onClick={logout}
                disabled={pending}
                className="btn btn-outline !px-3 !py-1.5 !text-xs"
              >
                خروج
              </button>
            </div>
          ) : (
            <Link href="/login" className="btn btn-primary !px-4 !py-2 !text-xs sm:!text-sm">
              ابدئي التحدي
            </Link>
          )}

          <button
            type="button"
            aria-label="القائمة"
            onClick={() => setOpen((value) => !value)}
            className="grid h-9 w-9 place-items-center rounded-xl border border-brand-100 bg-white text-brand-800 md:hidden"
          >
            {open ? "✕" : "☰"}
          </button>
        </div>
      </div>

      {open ? (
        <nav className="border-t border-brand-100 bg-white/95 px-4 pb-4 pt-2 md:hidden">
          <div className="flex flex-col gap-1">
            {links.map((link) => {
              const active =
                link.href === "/" ? pathname === "/" : pathname.startsWith(link.href);
              return (
                <Link
                  key={link.href}
                  href={link.href}
                  onClick={() => setOpen(false)}
                  className={`rounded-xl px-3 py-2.5 text-sm font-bold ${
                    active ? "bg-brand-50 text-brand-800" : "text-ink-700"
                  }`}
                >
                  {link.label}
                </Link>
              );
            })}
            {!user ? (
              <Link
                href="/admin"
                onClick={() => setOpen(false)}
                className="rounded-xl px-3 py-2.5 text-sm font-bold text-ink-500"
              >
                لوحة المشرفة
              </Link>
            ) : null}
          </div>
        </nav>
      ) : null}
    </header>
  );
}

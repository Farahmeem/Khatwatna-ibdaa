"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";

type Props = {
  existingNames: string[];
  isAdminPasswordDefault: boolean;
  defaultMode?: "participant" | "admin";
};

export default function LoginForm({
  existingNames,
  isAdminPasswordDefault,
  defaultMode = "participant",
}: Props) {
  const router = useRouter();
  const [mode, setMode] = useState<"participant" | "admin">(defaultMode);
  const [name, setName] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function submitParticipant(event: React.FormEvent) {
    event.preventDefault();
    setError(null);
    if (name.trim().length < 2) {
      setError("يرجى إدخال الاسم (حرفان على الأقل).");
      return;
    }
    setLoading(true);
    try {
      const response = await fetch("/api/auth/participant", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name }),
      });
      const data = (await response.json()) as { ok?: boolean; error?: string };
      if (!response.ok || !data.ok) {
        setError(data.error ?? "تعذّر تسجيل الدخول.");
        return;
      }
      router.push("/dashboard");
      router.refresh();
    } catch {
      setError("حدث خطأ في الاتصال، حاولي مرة أخرى.");
    } finally {
      setLoading(false);
    }
  }

  async function submitAdmin(event: React.FormEvent) {
    event.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const response = await fetch("/api/auth/admin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password }),
      });
      const data = (await response.json()) as { ok?: boolean; error?: string };
      if (!response.ok || !data.ok) {
        setError(data.error ?? "كلمة المرور غير صحيحة.");
        return;
      }
      router.push("/admin");
      router.refresh();
    } catch {
      setError("حدث خطأ في الاتصال، حاولي مرة أخرى.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="card p-6 sm:p-8">
      <div className="mb-6 grid grid-cols-2 gap-2 rounded-2xl bg-brand-50 p-1">
        <button
          type="button"
          onClick={() => {
            setMode("participant");
            setError(null);
          }}
          className={`rounded-xl px-3 py-2.5 text-sm font-extrabold transition ${
            mode === "participant"
              ? "bg-white text-brand-800 shadow-sm"
              : "text-ink-500 hover:text-brand-700"
          }`}
        >
          👟 مشاركة
        </button>
        <button
          type="button"
          onClick={() => {
            setMode("admin");
            setError(null);
          }}
          className={`rounded-xl px-3 py-2.5 text-sm font-extrabold transition ${
            mode === "admin"
              ? "bg-white text-brand-800 shadow-sm"
              : "text-ink-500 hover:text-brand-700"
          }`}
        >
          👩‍💼 مشرفة
        </button>
      </div>

      {mode === "participant" ? (
        <form onSubmit={submitParticipant} className="space-y-4">
          <div>
            <label htmlFor="name" className="mb-1.5 block text-sm font-bold text-brand-900">
              الاسم
            </label>
            <input
              id="name"
              className="field"
              placeholder="اكتبي اسمكِ كما تحبين أن يظهر"
              value={name}
              onChange={(event) => setName(event.target.value)}
              list="participant-names"
              autoComplete="off"
              maxLength={40}
            />
            <datalist id="participant-names">
              {existingNames.map((item) => (
                <option key={item} value={item} />
              ))}
            </datalist>
            <p className="mt-1.5 text-xs text-ink-500">
              إذا كان اسمكِ مسجّلاً سابقاً ستدخلين إلى ملفكِ مباشرة، وإن لم يكن سيُنشأ لكِ ملف جديد
              بخطواتكِ ونقاطكِ الخاصة.
            </p>
          </div>

          {existingNames.length > 0 ? (
            <div>
              <p className="mb-2 text-xs font-bold text-ink-500">أو اختاري اسمكِ من المشاركات:</p>
              <div className="flex max-h-32 flex-wrap gap-2 overflow-y-auto">
                {existingNames.map((item) => (
                  <button
                    key={item}
                    type="button"
                    onClick={() => setName(item)}
                    className={`rounded-full border px-3 py-1.5 text-xs font-bold transition ${
                      name === item
                        ? "border-brand-400 bg-brand-500 text-white"
                        : "border-brand-100 bg-white text-brand-800 hover:bg-brand-50"
                    }`}
                  >
                    {item}
                  </button>
                ))}
              </div>
            </div>
          ) : null}

          {error ? (
            <p className="rounded-xl border border-rose-200 bg-rose-50 px-3 py-2 text-sm font-bold text-rose-700">
              {error}
            </p>
          ) : null}

          <button type="submit" className="btn btn-primary w-full" disabled={loading}>
            {loading ? "جارٍ الدخول..." : "ابدئي التحدي 🌿"}
          </button>
        </form>
      ) : (
        <form onSubmit={submitAdmin} className="space-y-4">
          <div>
            <label htmlFor="password" className="mb-1.5 block text-sm font-bold text-brand-900">
              كلمة مرور المشرفة
            </label>
            <input
              id="password"
              type="password"
              className="field"
              placeholder="••••••••"
              value={password}
              onChange={(event) => setPassword(event.target.value)}
              autoComplete="current-password"
            />
            {isAdminPasswordDefault ? (
              <p className="mt-2 rounded-xl bg-gold-50 px-3 py-2 text-xs font-bold text-gold-600">
                كلمة المرور الافتراضية: <span dir="ltr">ibdaa2026</span> — يمكن تغييرها من متغيّر
                البيئة <span dir="ltr">ADMIN_PASSWORD</span>.
              </p>
            ) : null}
          </div>

          {error ? (
            <p className="rounded-xl border border-rose-200 bg-rose-50 px-3 py-2 text-sm font-bold text-rose-700">
              {error}
            </p>
          ) : null}

          <button type="submit" className="btn btn-gold w-full" disabled={loading}>
            {loading ? "جارٍ التحقق..." : "الدخول إلى لوحة المشرفة"}
          </button>
        </form>
      )}
    </div>
  );
}

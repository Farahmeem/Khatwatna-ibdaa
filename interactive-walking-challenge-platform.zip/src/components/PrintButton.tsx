"use client";

export default function PrintButton({ label = "🖨️ طباعة البطاقة" }: { label?: string }) {
  return (
    <button type="button" onClick={() => window.print()} className="btn btn-outline !py-2 !text-xs">
      {label}
    </button>
  );
}

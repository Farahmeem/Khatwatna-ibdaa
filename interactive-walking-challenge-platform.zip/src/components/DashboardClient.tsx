"use client";

import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import {
  DAILY_GOAL,
  DOMAIN_ICONS,
  DOMAIN_LABELS,
  WEEKLY_GOAL,
} from "@/lib/constants";
import {
  clampPercent,
  formatDateTime,
  formatKm,
  formatNumber,
  formatPercent,
} from "@/lib/format";
import type { DashboardPayload, DayView } from "@/lib/types";
import CelebrationModal from "./CelebrationModal";
import { DomainBadge, ProgressBar } from "./ui";

type Toast = { type: "success" | "error" | "info"; message: string } | null;

export default function DashboardClient({ initial }: { initial: DashboardPayload }) {
  const [data, setData] = useState<DashboardPayload>(initial);
  const [celebration, setCelebration] = useState<{ dayIndex: number; text: string } | null>(
    initial.celebration,
  );
  const [toast, setToast] = useState<Toast>(null);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    if (initial.celebration) setCelebration(initial.celebration);
  }, [initial.celebration]);

  const reload = useCallback(async (silent = true) => {
    if (!silent) setRefreshing(true);
    try {
      const response = await fetch("/api/dashboard", { cache: "no-store" });
      if (response.ok) {
        const payload = (await response.json()) as DashboardPayload;
        setData(payload);
      }
    } catch {
      // تجاهل أخطاء الشبكة المؤقتة
    } finally {
      if (!silent) setRefreshing(false);
    }
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      void reload(true);
    }, 15_000);
    return () => clearInterval(timer);
  }, [reload]);

  useEffect(() => {
    if (!toast) return;
    const timer = setTimeout(() => setToast(null), 4500);
    return () => clearTimeout(timer);
  }, [toast]);

  const { summary, week } = data;
  const todaySteps = summary.todaySteps;
  const remaining = Math.max(0, WEEKLY_GOAL - summary.totalSteps);

  async function saveSteps(dayIndex: number, steps: number, mode: "save" | "lock") {
    try {
      const response = await fetch("/api/steps", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ dayIndex, steps, action: mode }),
      });
      const payload = (await response.json()) as {
        ok?: boolean;
        error?: string;
        celebrate?: { dayIndex: number; text: string } | null;
      };

      if (!response.ok || !payload.ok) {
        setToast({ type: "error", message: payload.error ?? "تعذّر حفظ الخطوات." });
        return false;
      }

      if (payload.celebrate) {
        setCelebration(payload.celebrate);
      } else {
        setToast({
          type: "success",
          message:
            mode === "lock"
              ? "تم حفظ الخطوات واعتماد اليوم بنجاح ✅"
              : "تم حفظ الخطوات، يمكنكِ تعديلها قبل الاعتماد 💾",
        });
      }
      await reload();
      return true;
    } catch {
      setToast({ type: "error", message: "حدث خطأ في الاتصال، حاولي مرة أخرى." });
      return false;
    }
  }

  async function answerQuiz(dayIndex: number, chosenIndex: number) {
    try {
      const response = await fetch("/api/quiz", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ dayIndex, chosenIndex }),
      });
      const payload = (await response.json()) as {
        ok?: boolean;
        error?: string;
        isCorrect?: boolean;
        points?: number;
      };

      if (!response.ok || !payload.ok) {
        setToast({ type: "error", message: payload.error ?? "تعذّر تسجيل الإجابة." });
        await reload();
        return false;
      }

      setToast({
        type: payload.isCorrect ? "success" : "info",
        message: payload.isCorrect
          ? `إجابة صحيحة! أُضيفت ${payload.points ?? 10} نقاط إلى رصيدكِ المعرفي 🧠⭐`
          : "إجابة غير صحيحة، اطّلعي على التفسير المبسط بالأسفل 💡",
      });
      await reload();
      return true;
    } catch {
      setToast({ type: "error", message: "حدث خطأ في الاتصال، حاولي مرة أخرى." });
      return false;
    }
  }

  async function dismissCelebration() {
    const dayIndex = celebration?.dayIndex;
    setCelebration(null);
    if (dayIndex !== undefined) {
      try {
        await fetch("/api/steps", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ dayIndex, action: "celebrate" }),
        });
      } catch {
        // لا نعطّل التجربة إن فشل تعليم الاحتفال
      }
      await reload();
    }
  }

  return (
    <div className="mx-auto max-w-6xl px-4 py-8">
      {celebration ? (
        <CelebrationModal
          name={data.participant.name}
          steps={
            data.days.find((day) => day.dayIndex === celebration.dayIndex)?.steps ?? DAILY_GOAL
          }
          message={celebration.text}
          onClose={dismissCelebration}
        />
      ) : null}

      {toast ? (
        <div
          className={`fixed bottom-5 left-1/2 z-40 w-[92%] max-w-md -translate-x-1/2 rounded-2xl border px-4 py-3 text-sm font-bold shadow-xl ${
            toast.type === "success"
              ? "border-brand-200 bg-brand-600 text-white"
              : toast.type === "error"
                ? "border-rose-200 bg-rose-600 text-white"
                : "border-gold-200 bg-gold-100 text-gold-600"
          }`}
          role="status"
        >
          {toast.message}
        </div>
      ) : null}

      {/* رأس الصفحة */}
      <section className="card relative overflow-hidden p-5 sm:p-7">
        <div className="absolute -left-16 -top-16 h-40 w-40 rounded-full bg-brand-100/70 blur-2xl" />
        <div className="relative flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <span className="grid h-16 w-16 place-items-center rounded-2xl bg-gradient-to-br from-brand-100 to-white text-3xl shadow-inner">
              {data.participant.avatar}
            </span>
            <div>
              <p className="text-xs font-bold text-ink-500">ملف المشاركة · الأسبوع {week.weekNumber}</p>
              <h1 className="text-2xl font-extrabold text-brand-900 sm:text-3xl">
                أهلاً {data.participant.name} 👋
              </h1>
              <div className="mt-1 flex flex-wrap items-center gap-2">
                <span className="chip chip-gold">🏅 {data.levelLabel}</span>
                <span className="chip">👟 المركز {summary.rankSteps} في الخطوات</span>
                <span className="chip">🧠 المركز {summary.rankPoints} في النقاط</span>
              </div>
            </div>
          </div>

          <div className="flex flex-col items-start gap-2 sm:items-end">
            <div className="flex items-center gap-2">
              <span className="flex items-center gap-1.5 rounded-full bg-brand-50 px-3 py-1 text-[11px] font-bold text-brand-700">
                <span className="relative flex h-2 w-2">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-brand-400 opacity-75" />
                  <span className="relative inline-flex h-2 w-2 rounded-full bg-brand-500" />
                </span>
                تحديث مباشر
              </span>
              <button
                type="button"
                onClick={() => void reload(false)}
                disabled={refreshing}
                className="btn btn-soft !px-3 !py-1.5 !text-xs"
              >
                {refreshing ? "جارٍ التحديث..." : "🔄 تحديث"}
              </button>
            </div>
            <p className="text-[11px] font-medium text-ink-500">
              أسبوع التحدي: {week.days[0].weekday} {week.days[0].dateLabel} — {week.days[6].weekday}{" "}
              {week.days[6].dateLabel}
            </p>
            <div className="flex gap-2">
              <Link href="/achievements" className="text-xs font-bold text-brand-700 hover:underline">
                بطاقة إنجازي ←
              </Link>
              <Link href="/leaderboard" className="text-xs font-bold text-brand-700 hover:underline">
                لوحة المتصدرات ←
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* المؤشرات الثلاثة */}
      <section className="mt-5 grid gap-3 sm:grid-cols-3">
        <div className="card-tight p-4">
          <div className="flex items-center justify-between">
            <p className="text-xs font-bold text-ink-500">إجمالي خطوات المشي</p>
            <span className="text-lg">👟</span>
          </div>
          <p className="mt-1 text-2xl font-extrabold text-brand-900">
            {formatNumber(summary.totalSteps)}
            <span className="mr-1 text-xs font-bold text-ink-500">خطوة</span>
          </p>
          <p className="mt-1 text-[11px] font-medium text-ink-500">
            ≈ {formatKm(summary.totalSteps)} كم مقطوعة
          </p>
        </div>

        <div className="card-tight p-4">
          <div className="flex items-center justify-between">
            <p className="text-xs font-bold text-ink-500">نسبة إنجاز هدف المشي</p>
            <span className="text-lg">📊</span>
          </div>
          <p className="mt-1 text-2xl font-extrabold text-brand-900">
            {formatPercent(summary.percent, 1)}
          </p>
          <ProgressBar value={summary.percent} height="h-2" className="mt-2" />
          <p className="mt-1 text-[11px] font-medium text-ink-500">
            {formatNumber(summary.totalSteps)} ÷ {formatNumber(WEEKLY_GOAL)} خطوة أسبوعياً
          </p>
        </div>

        <div className="card-tight border-gold-200 bg-gradient-to-br from-gold-50 to-white p-4">
          <div className="flex items-center justify-between">
            <p className="text-xs font-bold text-ink-500">رصيد نقاط التحديات المعرفية</p>
            <span className="text-lg">🧠</span>
          </div>
          <p className="mt-1 text-2xl font-extrabold text-gold-600">
            {formatNumber(summary.points)}
            <span className="mr-1 text-xs font-bold text-ink-500">نقطة</span>
          </p>
          <p className="mt-1 text-[11px] font-medium text-ink-500">
            {summary.correctAnswers} إجابة صحيحة × 10 نقاط · منفصلة عن الخطوات
          </p>
        </div>
      </section>

      {/* شريط التقدم الأسبوعي */}
      <section className="card mt-5 p-5">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h2 className="text-lg font-extrabold text-brand-900">التقدم الأسبوعي</h2>
          <div className="flex items-center gap-2">
            <span className="chip">✅ {summary.completedDays} من 7 أيام مكتملة</span>
            <span className="chip chip-gold">
              خطوات اليوم: {formatNumber(todaySteps)}
            </span>
          </div>
        </div>
        <ProgressBar value={summary.percent} className="mt-3" height="h-4" />
        <div className="mt-2 flex flex-wrap items-center justify-between gap-2 text-xs font-bold text-ink-500">
          <span>0</span>
          <span className="text-brand-700">
            متبقٍ {formatNumber(remaining)} خطوة للوصول إلى {formatNumber(WEEKLY_GOAL)} خطوة
          </span>
          <span>{formatNumber(WEEKLY_GOAL)}</span>
        </div>
      </section>

      {/* بطاقات الأيام */}
      <section className="mt-8">
        <div className="mb-4 flex flex-wrap items-end justify-between gap-2">
          <div>
            <h2 className="text-2xl font-extrabold text-brand-900">أيام التحدي السبعة</h2>
            <p className="mt-1 text-sm text-ink-500">
              أدخلي خطواتكِ ثم اعتمدي اليوم. كل بطاقة تنتهي بسؤال التحدي اليومي 🧠
            </p>
          </div>
          <span className="chip">🎯 الهدف اليومي: {formatNumber(DAILY_GOAL)} خطوة</span>
        </div>

        <div className="grid gap-4 lg:grid-cols-2">
          {data.days.map((day) => (
            <DayCard
              key={`${week.weekNumber}-${day.dayIndex}`}
              day={day}
              onSave={saveSteps}
              onAnswer={answerQuiz}
            />
          ))}
        </div>
      </section>

      {/* الشارات */}
      <section className="card mt-8 p-5">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h2 className="text-lg font-extrabold text-brand-900">شاراتكِ في هذا الأسبوع</h2>
          <Link href="/achievements" className="text-xs font-bold text-brand-700 hover:underline">
            بطاقة الإنجاز الكاملة ←
          </Link>
        </div>
        <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
          {data.badges.map((badge) => (
            <div
              key={badge.id}
              className={`rounded-2xl border px-3 py-3 text-center transition ${
                badge.earned
                  ? "border-gold-200 bg-gold-50 text-gold-600"
                  : "border-brand-100 bg-brand-50/40 text-ink-500 opacity-70"
              }`}
            >
              <span className="text-2xl">{badge.icon}</span>
              <p className="mt-1 text-xs font-extrabold">{badge.title}</p>
              <p className="mt-0.5 text-[10px] leading-4">{badge.description}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

function DayCard({
  day,
  onSave,
  onAnswer,
}: {
  day: DayView;
  onSave: (dayIndex: number, steps: number, mode: "save" | "lock") => Promise<boolean>;
  onAnswer: (dayIndex: number, chosenIndex: number) => Promise<boolean>;
}) {
  const [draft, setDraft] = useState<string>(`${day.steps}`);
  const [saving, setSaving] = useState<"save" | "lock" | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [answering, setAnswering] = useState<number | null>(null);

  useEffect(() => {
    setDraft(`${day.steps}`);
  }, [day.steps]);

  const disabled = day.locked || day.isFuture;
  const numeric = Number(draft);
  const previewSteps = Number.isFinite(numeric) && numeric > 0 ? numeric : 0;
  const answer = day.quiz.answer;

  async function handleSave(mode: "save" | "lock") {
    setError(null);
    if (!Number.isInteger(numeric) || numeric < 0 || numeric > 200_000) {
      setError("أدخلي عدداً صحيحاً بين 0 و200,000 خطوة.");
      return;
    }
    setSaving(mode);
    const ok = await onSave(day.dayIndex, numeric, mode);
    setSaving(null);
    if (!ok) setError("تعذّر الحفظ، حاولي مرة أخرى.");
  }

  return (
    <article
      className={`card relative overflow-hidden p-5 ${
        day.isToday ? "ring-2 ring-brand-300" : ""
      }`}
    >
      {day.goalMet ? (
        <div className="absolute inset-x-0 top-0 h-1 bg-gradient-to-l from-gold-300 via-brand-400 to-gold-300" />
      ) : null}

      <header className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <div className="flex items-center gap-2">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-brand-50 text-sm font-extrabold text-brand-800">
              {day.dayIndex + 1}
            </span>
            <div>
              <h3 className="text-base font-extrabold text-brand-900">
                {day.weekday} <span className="text-xs font-bold text-ink-500">· {day.dateLabel}</span>
              </h3>
              <p className="text-[11px] font-medium text-ink-500">
                {day.isToday ? "اليوم الحالي" : day.isFuture ? "لم يحن بعد" : "يوم سابق"}
              </p>
            </div>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-1.5">
          {day.isToday ? <span className="chip">⭐ اليوم</span> : null}
          {day.locked ? <span className="chip chip-gold">🔒 معتمد</span> : null}
          {day.goalMet ? <span className="chip chip-gold">🎉 الهدف تحقق</span> : null}
        </div>
      </header>

      <div className="mt-4 rounded-2xl border border-brand-100 bg-brand-50/40 p-3">
        <div className="flex flex-wrap items-end gap-2">
          <div className="flex-1">
            <label
              htmlFor={`steps-${day.dayIndex}`}
              className="mb-1 block text-xs font-bold text-ink-500"
            >
              عدد الخطوات المسجّلة
            </label>
            <div className="flex gap-2">
              <input
                id={`steps-${day.dayIndex}`}
                type="number"
                inputMode="numeric"
                min={0}
                max={200000}
                step={1}
                disabled={disabled}
                value={draft}
                onChange={(event) => setDraft(event.target.value)}
                className="field hide-spin !py-2 text-center font-extrabold"
                placeholder="مثال: 8000"
              />
              <button
                type="button"
                disabled={disabled || saving !== null}
                onClick={() => void handleSave("save")}
                className="btn btn-soft shrink-0 !px-3 !py-2 !text-xs"
              >
                {saving === "save" ? "..." : "💾 حفظ"}
              </button>
              <button
                type="button"
                disabled={disabled || saving !== null}
                onClick={() => void handleSave("lock")}
                className="btn btn-primary shrink-0 !px-3 !py-2 !text-xs"
              >
                {saving === "lock" ? "..." : "✅ اعتماد"}
              </button>
            </div>
          </div>
        </div>

        {!disabled ? (
          <div className="mt-2 flex flex-wrap items-center gap-1.5">
            <span className="text-[10px] font-bold text-ink-500">إضافة سريعة:</span>
            {[1000, 2500, 5000].map((amount) => (
              <button
                key={amount}
                type="button"
                onClick={() => {
                  const base = Number.isFinite(numeric) ? numeric : 0;
                  setDraft(`${Math.min(200000, Math.max(0, base + amount))}`);
                }}
                className="rounded-full border border-brand-200 bg-white px-2 py-0.5 text-[10px] font-extrabold text-brand-700 hover:bg-brand-50"
              >
                +{formatNumber(amount)}
              </button>
            ))}
            <button
              type="button"
              onClick={() => setDraft(`${DAILY_GOAL}`)}
              className="rounded-full border border-gold-200 bg-gold-50 px-2 py-0.5 text-[10px] font-extrabold text-gold-600 hover:bg-gold-100"
            >
              🎯 هدف اليوم
            </button>
          </div>
        ) : (
          <p className="mt-2 text-[11px] font-bold text-ink-500">
            {day.isFuture
              ? "🔒 يُفتح إدخال الخطوات في يومه المحدد."
              : "🔒 تم اعتماد هذا اليوم، إن أردتِ تعديله تواصلي مع المشرفة."}
          </p>
        )}

        {error ? <p className="mt-1 text-[11px] font-bold text-rose-600">{error}</p> : null}

        <div className="mt-3 grid grid-cols-3 gap-2 text-center">
          <div className="rounded-xl bg-white px-2 py-1.5">
            <p className="text-[10px] font-bold text-ink-500">الكيلومترات</p>
            <p className="text-sm font-extrabold text-brand-800">{formatKm(day.steps)} كم</p>
          </div>
          <div className="rounded-xl bg-white px-2 py-1.5">
            <p className="text-[10px] font-bold text-ink-500">من الهدف اليومي</p>
            <p className="text-sm font-extrabold text-brand-800">
              {formatPercent(day.dailyPercent)}
            </p>
          </div>
          <div className="rounded-xl bg-white px-2 py-1.5">
            <p className="text-[10px] font-bold text-ink-500">المتبقي للهدف</p>
            <p className="text-sm font-extrabold text-brand-800">
              {formatNumber(Math.max(0, DAILY_GOAL - day.steps))}
            </p>
          </div>
        </div>

        <ProgressBar
          value={clampPercent(day.dailyPercent)}
          gold={day.goalMet}
          height="h-2"
          className="mt-2"
        />
        {previewSteps !== day.steps ? (
          <p className="mt-1 text-[10px] font-bold text-gold-600">
            معاينة قبل الحفظ: {formatNumber(previewSteps)} خطوة
          </p>
        ) : null}
      </div>

      {/* رسالة تحفيزية مدمجة بالمادة */}
      <div className="mt-3 rounded-2xl border border-gold-100 bg-gold-50/60 p-3">
        <div className="flex items-center justify-between gap-2">
          <DomainBadge domain={day.motivation.domain} />
          <span className="chip chip-gold">✨ {day.motivation.levelLabel}</span>
        </div>
        {day.motivation.domain === "english" ? (
          <p
            dir="ltr"
            className="mt-2 rounded-xl bg-white/80 px-3 py-2 text-left text-sm font-extrabold text-brand-900"
          >
            {day.motivation.text}
          </p>
        ) : (
          <p className="mt-2 text-sm font-bold leading-6 text-ink-700">{day.motivation.text}</p>
        )}
        {day.motivation.translation ? (
          <p className="mt-1 text-xs font-medium text-ink-500">
            الترجمة: {day.motivation.translation}
          </p>
        ) : null}
      </div>

      {/* التحدي المعرفي */}
      <div className="mt-3 rounded-2xl border border-brand-100 bg-white p-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-1.5 text-sm font-extrabold text-brand-900">
            <span>🧠</span> سؤال التحدي اليومي
          </div>
          <DomainBadge domain={day.quiz.domain} />
        </div>

        {!day.quiz.available ? (
          <p className="mt-2 rounded-xl bg-brand-50/70 px-3 py-2 text-xs font-bold text-ink-500">
            🔒 يُفتح سؤال هذا اليوم في يومه المحدد.
          </p>
        ) : (
          <>
            <p className="mt-2 text-sm font-bold leading-6 text-ink-700">{day.quiz.prompt}</p>

            <div className="mt-2 grid gap-1.5">
              {day.quiz.options.map((option, index) => {
                const isCorrectOption = answer ? index === answer.correctIndex : false;
                const isChosen = answer ? index === answer.chosenIndex : false;
                const base =
                  "rounded-xl border px-3 py-2 text-right text-xs font-bold transition flex items-center gap-2";
                const style = answer
                  ? isCorrectOption
                    ? "border-brand-300 bg-brand-50 text-brand-800"
                    : isChosen
                      ? "border-rose-200 bg-rose-50 text-rose-700"
                      : "border-slate-100 bg-slate-50/60 text-ink-500"
                  : "border-brand-100 bg-white text-ink-700 hover:border-brand-300 hover:bg-brand-50";

                return (
                  <button
                    key={`${day.dayIndex}-${index}`}
                    type="button"
                    disabled={Boolean(answer) || answering !== null}
                    onClick={async () => {
                      setAnswering(index);
                      await onAnswer(day.dayIndex, index);
                      setAnswering(null);
                    }}
                    className={`${base} ${style}`}
                  >
                    <span className="grid h-5 w-5 shrink-0 place-items-center rounded-full bg-white text-[10px] font-extrabold text-brand-700 shadow-sm">
                      {["أ", "ب", "ج", "د"][index] ?? index + 1}
                    </span>
                    <span className="flex-1">{option}</span>
                    {answer && isCorrectOption ? <span>✅</span> : null}
                    {answer && isChosen && !isCorrectOption ? <span>❌</span> : null}
                    {!answer && answering === index ? <span>⏳</span> : null}
                  </button>
                );
              })}
            </div>

            {answer ? (
              <div
                className={`mt-2 rounded-xl border px-3 py-2 text-xs font-bold leading-5 ${
                  answer.isCorrect
                    ? "border-brand-200 bg-brand-50 text-brand-800"
                    : "border-amber-200 bg-amber-50 text-amber-800"
                }`}
              >
                <p>
                  {answer.isCorrect
                    ? `🎉 إجابة صحيحة! +${answer.points} نقاط معرفية.`
                    : "💡 إجابة غير صحيحة، والإجابة الصحيحة هي:"}{" "}
                  {!answer.isCorrect ? (
                    <span className="font-extrabold">{answer.options[answer.correctIndex]}</span>
                  ) : null}
                </p>
                <p className="mt-1 font-medium text-ink-500">التفسير: {answer.explanation}</p>
                <p className="mt-1 text-[10px] font-medium text-ink-500">
                  وقت الإجابة: {formatDateTime(answer.answeredAt)} · لكل سؤال محاولة واحدة فقط.
                </p>
              </div>
            ) : (
              <p className="mt-2 text-[10px] font-medium text-ink-500">
                الإجابة الصحيحة تمنحكِ 10 نقاط معرفية، ولا يمكن احتساب السؤال أكثر من مرة.
              </p>
            )}
          </>
        )}
      </div>

      <div className="mt-3 flex items-center justify-between text-[10px] font-medium text-ink-500">
        <span>{DOMAIN_ICONS[day.quiz.domain]} مجال اليوم: {DOMAIN_LABELS[day.quiz.domain]}</span>
        <span>{day.goalMet ? "⭐ يوم مكتمل" : "خطوة بعد خطوة نحو الهدف"}</span>
      </div>
    </article>
  );
}

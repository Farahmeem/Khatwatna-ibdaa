"use client";

import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import { DOMAIN_ICONS, DOMAIN_LABELS, MEDALS } from "@/lib/constants";
import { formatDateTime, formatNumber, formatPercent } from "@/lib/format";
import type { AdminData } from "@/lib/types";
import { ProgressBar } from "./ui";

type Toast = { type: "success" | "error" | "info"; message: string } | null;
type Tab = "overview" | "participants" | "steps" | "answers" | "settings";

const TABS: { id: Tab; label: string; icon: string }[] = [
  { id: "overview", label: "نظرة عامة", icon: "📊" },
  { id: "participants", label: "المشاركات", icon: "👥" },
  { id: "steps", label: "تعديل الخطوات", icon: "👟" },
  { id: "answers", label: "الإجابات", icon: "🧠" },
  { id: "settings", label: "الإعدادات والتصدير", icon: "⚙️" },
];

export default function AdminClient({
  initial,
  isDefaultPassword,
}: {
  initial: AdminData;
  isDefaultPassword: boolean;
}) {
  const [data, setData] = useState<AdminData>(initial);
  const [tab, setTab] = useState<Tab>("overview");
  const [toast, setToast] = useState<Toast>(null);
  const [busy, setBusy] = useState(false);
  const [newName, setNewName] = useState("");
  const [editing, setEditing] = useState<{ id: string; name: string } | null>(null);
  const [domainFilter, setDomainFilter] = useState<string>("all");
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!toast) return;
    const timer = setTimeout(() => setToast(null), 4500);
    return () => clearTimeout(timer);
  }, [toast]);

  const reload = useCallback(async () => {
    try {
      const response = await fetch("/api/admin/overview", { cache: "no-store" });
      if (response.ok) setData((await response.json()) as AdminData);
    } catch {
      // نحافظ على آخر بيانات
    }
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      void reload();
    }, 15_000);
    return () => clearInterval(timer);
  }, [reload]);

  async function call(
    url: string,
    body: Record<string, unknown>,
    successMessage: string,
  ): Promise<boolean> {
    setBusy(true);
    try {
      const response = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const payload = (await response.json()) as { ok?: boolean; error?: string; message?: string };
      if (!response.ok || !payload.ok) {
        setToast({ type: "error", message: payload.error ?? "تعذّر تنفيذ العملية." });
        return false;
      }
      setToast({ type: "success", message: payload.message ?? successMessage });
      await reload();
      return true;
    } catch {
      setToast({ type: "error", message: "حدث خطأ في الاتصال." });
      return false;
    } finally {
      setBusy(false);
    }
  }

  async function addParticipant(event: React.FormEvent) {
    event.preventDefault();
    if (newName.trim().length < 2) {
      setToast({ type: "error", message: "أدخلي اسماً صحيحاً." });
      return;
    }
    const ok = await call(
      "/api/admin/participants",
      { action: "create", name: newName },
      "تمت إضافة المشاركة بنجاح.",
    );
    if (ok) setNewName("");
  }

  async function saveStepsRow(participantId: string, rows: { dayIndex: number; steps: number }[]) {
    setBusy(true);
    let failed = false;
    for (const row of rows) {
      try {
        const response = await fetch("/api/admin/steps", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ participantId, dayIndex: row.dayIndex, steps: row.steps }),
        });
        if (!response.ok) failed = true;
      } catch {
        failed = true;
      }
    }
    setBusy(false);
    setToast(
      failed
        ? { type: "error", message: "تعذّر حفظ بعض الأيام، حاولي مرة أخرى." }
        : { type: "success", message: "تم تحديث خطوات المشاركة ✅" },
    );
    await reload();
  }

  const shareUrl = typeof window !== "undefined" ? window.location.origin : "";

  async function copyLink() {
    try {
      await navigator.clipboard.writeText(shareUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
      setToast({ type: "success", message: "تم نسخ رابط المشاركة المشترك ✅" });
    } catch {
      setToast({ type: "info", message: shareUrl });
    }
  }

  const filteredAnswers =
    domainFilter === "all"
      ? data.answers
      : data.answers.filter((answer) => answer.domain === domainFilter);

  return (
    <div className="mx-auto max-w-6xl px-4 py-8">
      {toast ? (
        <div
          className={`fixed bottom-5 left-1/2 z-50 w-[92%] max-w-md -translate-x-1/2 rounded-2xl border px-4 py-3 text-sm font-bold shadow-xl ${
            toast.type === "success"
              ? "border-brand-200 bg-brand-600 text-white"
              : toast.type === "error"
                ? "border-rose-200 bg-rose-600 text-white"
                : "border-gold-200 bg-gold-100 text-gold-600"
          }`}
          role="status"
        >
          {toast.message}
        </div>
      ) : null}

      <section className="card relative overflow-hidden p-5 sm:p-7">
        <div className="pattern-dots absolute inset-0 opacity-20" />
        <div className="relative flex flex-wrap items-center justify-between gap-4">
          <div>
            <span className="chip chip-gold">👩‍💼 لوحة المشرفة</span>
            <h1 className="mt-2 text-2xl font-extrabold text-brand-900 sm:text-3xl">
              إدارة تحدي خطواتنا إبداع
            </h1>
            <p className="mt-1 text-sm text-ink-500">
              الأسبوع {data.week.weekNumber} · {data.week.days[0].weekday}{" "}
              {data.week.days[0].dateLabel} — {data.week.days[6].weekday}{" "}
              {data.week.days[6].dateLabel}
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <span className="flex items-center gap-1.5 rounded-full bg-brand-50 px-3 py-1 text-[11px] font-bold text-brand-700">
              <span className="relative flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-brand-400 opacity-75" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-brand-500" />
              </span>
              متزامن
            </span>
            <button
              type="button"
              onClick={() => void reload()}
              className="btn btn-soft !px-3 !py-1.5 !text-xs"
            >
              🔄 تحديث
            </button>
            <Link href="/leaderboard" className="btn btn-outline !px-3 !py-1.5 !text-xs">
              لوحة المتصدرات
            </Link>
          </div>
        </div>

        <div className="scroll-x relative mt-5">
          <div className="flex min-w-max gap-1 rounded-2xl bg-brand-50 p-1">
            {TABS.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => setTab(item.id)}
                className={`rounded-xl px-3.5 py-2 text-xs font-extrabold transition sm:text-sm ${
                  tab === item.id
                    ? "bg-white text-brand-800 shadow-sm"
                    : "text-ink-500 hover:text-brand-700"
                }`}
              >
                {item.icon} {item.label}
              </button>
            ))}
          </div>
        </div>
      </section>

      {tab === "overview" ? (
        <section className="mt-5 space-y-4">
          <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
            {[
              { label: "عدد المشاركات", value: formatNumber(data.totals.participants), icon: "👥", hint: "مشاركات مسجّلة" },
              { label: "إجمالي الخطوات", value: formatNumber(data.totals.steps), icon: "👟", hint: `${formatNumber(data.totals.km)} كم` },
              { label: "نقاط المعرفة", value: formatNumber(data.totals.points), icon: "🧠", hint: `${formatNumber(data.totals.answers)} إجابة مسجّلة` },
              { label: "الأيام المكتملة", value: formatNumber(data.totals.completedDays), icon: "✅", hint: "أيام بلغت 10,000 خطوة" },
            ].map((item) => (
              <div key={item.label} className="card-tight p-4">
                <p className="text-xs font-bold text-ink-500">
                  {item.icon} {item.label}
                </p>
                <p className="mt-1 text-2xl font-extrabold text-brand-900">{item.value}</p>
                <p className="text-[11px] font-medium text-ink-500">{item.hint}</p>
              </div>
            ))}
          </div>

          <div className="card overflow-hidden">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-brand-100 px-4 py-3">
              <h2 className="text-sm font-extrabold text-brand-900">جميع النتائج</h2>
              <span className="chip">
                دقة الإجابات: {formatPercent(data.totals.correctRate, 1)}
              </span>
            </div>
            <div className="scroll-x">
              <table className="w-full min-w-[820px] text-right text-xs">
                <thead className="bg-brand-50/80 text-brand-800">
                  <tr>
                    <th className="px-3 py-2.5 font-extrabold">المركز</th>
                    <th className="px-3 py-2.5 font-extrabold">المشاركة</th>
                    <th className="px-3 py-2.5 font-extrabold">الخطوات</th>
                    <th className="px-3 py-2.5 font-extrabold">الإنجاز</th>
                    <th className="px-3 py-2.5 font-extrabold">أيام مكتملة</th>
                    <th className="px-3 py-2.5 font-extrabold">نقاط</th>
                    <th className="px-3 py-2.5 font-extrabold">إجابات صحيحة</th>
                    <th className="px-3 py-2.5 font-extrabold">آخر 7 أيام</th>
                  </tr>
                </thead>
                <tbody>
                  {data.rows.map((row) => {
                    const grid = data.stepsGrid.find((item) => item.participantId === row.id);
                    return (
                      <tr key={row.id} className="border-t border-brand-50">
                        <td className="px-3 py-2.5 font-extrabold">
                          {row.rankSteps <= 3 ? MEDALS[row.rankSteps - 1] : row.rankSteps}
                        </td>
                        <td className="px-3 py-2.5 font-extrabold text-brand-900">
                          {row.avatar} {row.name}
                        </td>
                        <td className="px-3 py-2.5">{formatNumber(row.totalSteps)}</td>
                        <td className="px-3 py-2.5">
                          <div className="flex items-center gap-2">
                            <div className="w-16">
                              <ProgressBar value={row.percent} height="h-1.5" />
                            </div>
                            <span>{formatPercent(row.percent)}</span>
                          </div>
                        </td>
                        <td className="px-3 py-2.5">{row.completedDays}/7</td>
                        <td className="px-3 py-2.5 font-extrabold text-gold-600">{row.points}</td>
                        <td className="px-3 py-2.5">{row.correctAnswers}</td>
                        <td className="px-3 py-2.5">
                          <div className="flex gap-1">
                            {grid?.days.map((day) => (
                              <span
                                key={day.dayIndex}
                                title={`${formatNumber(day.steps)} خطوة`}
                                className={`h-2.5 w-4 rounded-sm ${
                                  day.steps >= 10000
                                    ? "bg-brand-500"
                                    : day.steps > 0
                                      ? "bg-brand-300"
                                      : "bg-brand-100"
                                }`}
                              />
                            ))}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                  {data.rows.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="px-3 py-8 text-center text-sm font-bold text-ink-500">
                        لا توجد مشاركات مسجّلة بعد.
                      </td>
                    </tr>
                  ) : null}
                </tbody>
              </table>
            </div>
          </div>
        </section>
      ) : null}

      {tab === "participants" ? (
        <section className="mt-5 grid gap-4 lg:grid-cols-[0.9fr_1.1fr]">
          <form onSubmit={addParticipant} className="card h-fit p-5">
            <h2 className="text-lg font-extrabold text-brand-900">➕ إضافة مشاركة جديدة</h2>
            <p className="mt-1 text-xs text-ink-500">
              سيتم إنشاء ملف خاص بالخطوات والنقاط مرتبط بمعرّف مستقل.
            </p>
            <label htmlFor="new-name" className="mt-4 block text-xs font-bold text-ink-500">
              اسم المشاركة
            </label>
            <input
              id="new-name"
              className="field mt-1"
              value={newName}
              onChange={(event) => setNewName(event.target.value)}
              placeholder="مثال: نورة"
              maxLength={40}
            />
            <button type="submit" className="btn btn-primary mt-3 w-full" disabled={busy}>
              {busy ? "..." : "إضافة المشاركة"}
            </button>
            <div className="mt-5 rounded-2xl bg-brand-50/70 p-3 text-[11px] font-medium leading-6 text-ink-500">
              💡 يمكن للمشاركة الدخول بنفسها أيضاً من صفحة الدخول بكتابة اسمها، وسيُنشأ ملف جديد
              تلقائياً إن لم يكن مسجّلاً.
            </div>
          </form>

          <div className="card p-5">
            <h2 className="text-lg font-extrabold text-brand-900">👥 إدارة المشاركات</h2>
            <div className="mt-3 space-y-2">
              {data.rows.map((row) => (
                <div
                  key={row.id}
                  className="flex flex-wrap items-center justify-between gap-2 rounded-2xl border border-brand-100 bg-white px-3 py-2.5"
                >
                  <div className="flex items-center gap-2">
                    <span className="grid h-8 w-8 place-items-center rounded-full bg-brand-50">
                      {row.avatar}
                    </span>
                    {editing?.id === row.id ? (
                      <input
                        className="field !py-1.5 !text-xs"
                        value={editing.name}
                        onChange={(event) => setEditing({ id: row.id, name: event.target.value })}
                        maxLength={40}
                      />
                    ) : (
                      <div>
                        <p className="text-sm font-extrabold text-brand-900">{row.name}</p>
                        <p className="text-[10px] font-medium text-ink-500">
                          {formatNumber(row.totalSteps)} خطوة · {row.points} نقطة
                        </p>
                      </div>
                    )}
                  </div>
                  <div className="flex items-center gap-1.5">
                    {editing?.id === row.id ? (
                      <>
                        <button
                          type="button"
                          className="btn btn-primary !px-2.5 !py-1 !text-[11px]"
                          disabled={busy}
                          onClick={async () => {
                            const ok = await call(
                              "/api/admin/participants",
                              { action: "rename", participantId: row.id, name: editing.name },
                              "تم تعديل الاسم.",
                            );
                            if (ok) setEditing(null);
                          }}
                        >
                          حفظ
                        </button>
                        <button
                          type="button"
                          className="btn btn-outline !px-2.5 !py-1 !text-[11px]"
                          onClick={() => setEditing(null)}
                        >
                          إلغاء
                        </button>
                      </>
                    ) : (
                      <>
                        <button
                          type="button"
                          className="btn btn-soft !px-2.5 !py-1 !text-[11px]"
                          onClick={() => setEditing({ id: row.id, name: row.name })}
                        >
                          ✏️ تعديل
                        </button>
                        <button
                          type="button"
                          className="btn !bg-rose-50 !px-2.5 !py-1 !text-[11px] !text-rose-700"
                          disabled={busy}
                          onClick={() => {
                            if (
                              window.confirm(
                                `سيتم حذف ${row.name} وجميع خطواتها وإجاباتها. هل تريدين المتابعة؟`,
                              )
                            ) {
                              void call(
                                "/api/admin/participants",
                                { action: "delete", participantId: row.id },
                                "تم حذف المشاركة.",
                              );
                            }
                          }}
                        >
                          🗑️ حذف
                        </button>
                      </>
                    )}
                  </div>
                </div>
              ))}
              {data.rows.length === 0 ? (
                <p className="rounded-2xl bg-brand-50/60 px-3 py-6 text-center text-sm font-bold text-ink-500">
                  لا توجد مشاركات بعد، أضيفي أول مشاركة.
                </p>
              ) : null}
            </div>
          </div>
        </section>
      ) : null}

      {tab === "steps" ? (
        <section className="mt-5 space-y-4">
          <div className="card p-5">
            <h2 className="text-lg font-extrabold text-brand-900">👟 تعديل خطوات المشاركات</h2>
            <p className="mt-1 text-xs text-ink-500">
              يمكنكِ تصحيح أي يوم لأي مشاركة. القيم المحفوظة تُحدّث النتائج ولوحة المتصدرات فوراً.
            </p>
            <div className="mt-4 space-y-3">
              {data.stepsGrid.map((grid) => (
                <AdminStepsRow
                  key={grid.participantId}
                  grid={grid}
                  dayLabels={data.week.days.map((day) => `${day.weekday} ${day.dateLabel}`)}
                  onSave={saveStepsRow}
                  busy={busy}
                />
              ))}
              {data.stepsGrid.length === 0 ? (
                <p className="rounded-2xl bg-brand-50/60 px-3 py-6 text-center text-sm font-bold text-ink-500">
                  لا توجد مشاركات لتعديل خطواتها.
                </p>
              ) : null}
            </div>
          </div>
        </section>
      ) : null}

      {tab === "answers" ? (
        <section className="mt-5 space-y-4">
          <div className="card p-5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h2 className="text-lg font-extrabold text-brand-900">🧠 مراجعة إجابات التحديات</h2>
              <select
                className="field !w-auto !py-1.5 !text-xs"
                value={domainFilter}
                onChange={(event) => setDomainFilter(event.target.value)}
              >
                <option value="all">كل المجالات</option>
                <option value="math">الرياضيات</option>
                <option value="arabic">اللغة العربية</option>
                <option value="english">اللغة الإنجليزية</option>
              </select>
            </div>

            <div className="scroll-x mt-3">
              <table className="w-full min-w-[860px] text-right text-xs">
                <thead className="bg-brand-50/80 text-brand-800">
                  <tr>
                    <th className="px-3 py-2.5 font-extrabold">المشاركة</th>
                    <th className="px-3 py-2.5 font-extrabold">اليوم</th>
                    <th className="px-3 py-2.5 font-extrabold">المجال</th>
                    <th className="px-3 py-2.5 font-extrabold">السؤال</th>
                    <th className="px-3 py-2.5 font-extrabold">الإجابة</th>
                    <th className="px-3 py-2.5 font-extrabold">الصحيحة</th>
                    <th className="px-3 py-2.5 font-extrabold">النتيجة</th>
                    <th className="px-3 py-2.5 font-extrabold">الوقت</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredAnswers.map((answer) => (
                    <tr key={answer.id} className="border-t border-brand-50 align-top">
                      <td className="px-3 py-2.5 font-bold text-brand-900">
                        {answer.avatar} {answer.participantName}
                      </td>
                      <td className="px-3 py-2.5">اليوم {answer.dayIndex + 1}</td>
                      <td className="px-3 py-2.5">
                        {DOMAIN_ICONS[answer.domain]} {DOMAIN_LABELS[answer.domain]}
                      </td>
                      <td className="max-w-[16rem] px-3 py-2.5 leading-5">{answer.prompt}</td>
                      <td
                        className={`max-w-[10rem] px-3 py-2.5 leading-5 ${
                          answer.isCorrect ? "text-brand-700" : "text-rose-600"
                        }`}
                      >
                        {answer.chosenText}
                      </td>
                      <td className="max-w-[10rem] px-3 py-2.5 leading-5">{answer.correctText}</td>
                      <td className="px-3 py-2.5">
                        {answer.isCorrect ? (
                          <span className="chip">✅ صحيحة · {answer.points}</span>
                        ) : (
                          <span className="chip !bg-rose-50 !text-rose-700 !border-rose-200">
                            ❌ خاطئة · 0
                          </span>
                        )}
                      </td>
                      <td className="px-3 py-2.5 text-[10px] text-ink-500">
                        {formatDateTime(answer.answeredAt)}
                      </td>
                    </tr>
                  ))}
                  {filteredAnswers.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="px-3 py-8 text-center text-sm font-bold text-ink-500">
                        لا توجد إجابات مسجّلة في هذا المجال.
                      </td>
                    </tr>
                  ) : null}
                </tbody>
              </table>
            </div>
          </div>
        </section>
      ) : null}

      {tab === "settings" ? (
        <section className="mt-5 grid gap-4 lg:grid-cols-2">
          <div className="card p-5">
            <h2 className="text-lg font-extrabold text-brand-900">🔗 رابط المشاركة المشترك</h2>
            <p className="mt-1 text-xs leading-6 text-ink-500">
              شاركي هذا الرابط مع جميع المشاركات للدخول إلى المنصة نفسها، وكل مشاركة سترى ملفها
              الخاص فقط.
            </p>
            <div className="mt-3 flex items-center gap-2 rounded-2xl border border-brand-100 bg-brand-50/60 px-3 py-2">
              <span dir="ltr" className="flex-1 truncate text-xs font-bold text-brand-800">
                {shareUrl || "—"}
              </span>
              <button type="button" onClick={copyLink} className="btn btn-soft !px-3 !py-1 !text-[11px]">
                {copied ? "تم النسخ ✅" : "نسخ"}
              </button>
            </div>
            <p className="mt-3 rounded-2xl bg-gold-50 px-3 py-2 text-[11px] font-bold leading-6 text-gold-600">
              🔐 كلمة مرور المشرفة:{" "}
              {isDefaultPassword ? (
                <>
                  الافتراضية <span dir="ltr">ibdaa2026</span> — يُفضّل تغييرها عبر متغيّر البيئة{" "}
                  <span dir="ltr">ADMIN_PASSWORD</span>.
                </>
              ) : (
                "مضبوطة عبر متغيّر البيئة ADMIN_PASSWORD."
              )}
            </p>
          </div>

          <div className="card p-5">
            <h2 className="text-lg font-extrabold text-brand-900">📥 تصدير النتائج</h2>
            <p className="mt-1 text-xs leading-6 text-ink-500">
              ملفات CSV متوافقة مع Excel وتحتوي على ترميز عربي سليم.
            </p>
            <div className="mt-3 flex flex-col gap-2">
              <a
                href="/api/admin/export?type=summary"
                className="btn btn-primary w-full !py-2.5 !text-sm"
              >
                📊 تصدير النتائج النهائية (الخطوات والنقاط)
              </a>
              <a
                href="/api/admin/export?type=answers"
                className="btn btn-outline w-full !py-2.5 !text-sm"
              >
                🧠 تصدير سجل إجابات التحديات
              </a>
            </div>
          </div>

          <div className="card p-5 lg:col-span-2">
            <h2 className="text-lg font-extrabold text-brand-900">🔄 إدارة أسابيع التحدي</h2>
            <p className="mt-1 text-xs leading-6 text-ink-500">
              عند بدء أسبوع جديد ترتفع قيمة رقم الأسبوع ويصبح تاريخ البداية اليوم، مع الاحتفاظ
              الكامل بنتائج الأسابيع السابقة في قاعدة البيانات.
            </p>
            <div className="mt-4 grid gap-3 sm:grid-cols-2">
              <button
                type="button"
                className="btn btn-gold w-full !py-2.5 !text-sm"
                disabled={busy}
                onClick={() => {
                  if (
                    window.confirm(
                      "سيتم بدء أسبوع جديد وتصفير عدّاد الأسبوع الحالي للمشاركات. هل أنتِ متأكدة؟",
                    )
                  ) {
                    void call(
                      "/api/admin/reset",
                      { action: "new-week" },
                      "تم بدء أسبوع جديد بنجاح.",
                    );
                  }
                }}
              >
                ▶️ بدء أسبوع جديد
              </button>
              <button
                type="button"
                className="btn !bg-rose-50 !py-2.5 !text-sm !text-rose-700"
                disabled={busy}
                onClick={() => {
                  if (
                    window.confirm(
                      "سيتم حذف جميع الخطوات والإجابات في الأسبوع الحالي فقط، مع بقاء أسماء المشاركات. هل أنتِ متأكدة؟",
                    )
                  ) {
                    void call(
                      "/api/admin/reset",
                      { action: "clear-week" },
                      "تم تفريغ بيانات الأسبوع الحالي.",
                    );
                  }
                }}
              >
                🧹 تفريغ بيانات الأسبوع الحالي
              </button>
            </div>
            <p className="mt-3 text-[11px] font-medium text-ink-500">
              الأسبوع الحالي: {data.week.weekNumber} · بداية الأسبوع: {data.week.days[0].weekday}{" "}
              {data.week.days[0].dateLabel} · نهاية الأسبوع: {data.week.days[6].weekday}{" "}
              {data.week.days[6].dateLabel}
            </p>

            <details className="mt-4 rounded-2xl border border-brand-100 bg-brand-50/60 px-3 py-2 text-[11px] leading-6 text-ink-500">
              <summary className="cursor-pointer font-extrabold text-brand-800">
                🔧 خطوات التفعيل والتشغيل
              </summary>
              <ul className="mt-2 list-disc pr-4">
                <li>
                  قاعدة البيانات: PostgreSQL عبر <span dir="ltr">DATABASE_URL</span> الموجود في ملف{" "}
                  <span dir="ltr">.env</span>.
                </li>
                <li>
                  تهيئة الجداول: <span dir="ltr">npx drizzle-kit push</span> (تم تنفيذها بالفعل
                  ويمكن تكرارها بأمان).
                </li>
                <li>
                  كلمة مرور المشرفة: <span dir="ltr">ADMIN_PASSWORD</span> في متغيّرات البيئة.
                </li>
                <li>
                  الرابط المشترك: أرسلي رابط المنصة نفسه لجميع المشاركات، ولكل مشاركة جلسة وملف
                  مستقل.
                </li>
                <li>مزامنة النتائج تلقائية كل 10–15 ثانية لجميع المستخدمات.</li>
              </ul>
            </details>
          </div>
        </section>
      ) : null}
    </div>
  );
}

function AdminStepsRow({
  grid,
  dayLabels,
  onSave,
  busy,
}: {
  grid: AdminData["stepsGrid"][number];
  dayLabels: string[];
  onSave: (participantId: string, rows: { dayIndex: number; steps: number }[]) => Promise<void>;
  busy: boolean;
}) {
  const [drafts, setDrafts] = useState<string[]>(grid.days.map((day) => `${day.steps}`));

  useEffect(() => {
    setDrafts(grid.days.map((day) => `${day.steps}`));
  }, [grid.days]);

  return (
    <div className="rounded-2xl border border-brand-100 bg-white p-3">
      <div className="mb-2 flex items-center justify-between gap-2">
        <p className="text-sm font-extrabold text-brand-900">
          {grid.avatar} {grid.participantName}
        </p>
        <button
          type="button"
          className="btn btn-primary !px-3 !py-1 !text-[11px]"
          disabled={busy}
          onClick={() => {
            const rows = grid.days.map((day, index) => ({
              dayIndex: day.dayIndex,
              steps: Math.max(0, Math.min(200000, Math.round(Number(drafts[index]) || 0))),
            }));
            void onSave(grid.participantId, rows);
          }}
        >
          💾 حفظ الصف
        </button>
      </div>
      <div className="grid grid-cols-4 gap-1.5 sm:grid-cols-7">
        {grid.days.map((day, index) => (
          <div key={day.dayIndex}>
            <label className="mb-1 block truncate text-[10px] font-bold text-ink-500" title={dayLabels[index]}>
              {dayLabels[index]}
            </label>
            <input
              type="number"
              inputMode="numeric"
              min={0}
              max={200000}
              value={drafts[index] ?? "0"}
              onChange={(event) => {
                const next = [...drafts];
                next[index] = event.target.value;
                setDrafts(next);
              }}
              className="field hide-spin !px-1.5 !py-1.5 text-center !text-xs font-bold"
            />
          </div>
        ))}
      </div>
    </div>
  );
}

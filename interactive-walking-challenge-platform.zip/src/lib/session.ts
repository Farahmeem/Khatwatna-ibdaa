import { randomUUID } from "crypto";
import { cookies } from "next/headers";
import { and, eq, gt, lt } from "drizzle-orm";
import { db } from "@/db";
import { participants, sessions } from "@/db/schema";
import { SESSION_COOKIE, SESSION_DAYS } from "./constants";
import type { SessionRole } from "./types";

export type AuthUser = {
  token: string;
  role: SessionRole;
  participantId: string | null;
  name: string;
  avatar: string;
};

export function getAdminPassword(): string {
  return process.env.ADMIN_PASSWORD?.trim() || "ibdaa2026";
}

export async function getAuthUser(): Promise<AuthUser | null> {
  const store = await cookies();
  const token = store.get(SESSION_COOKIE)?.value;
  if (!token) return null;

  const rows = await db
    .select({ session: sessions, participant: participants })
    .from(sessions)
    .leftJoin(participants, eq(sessions.participantId, participants.id))
    .where(and(eq(sessions.token, token), gt(sessions.expiresAt, new Date())))
    .limit(1);

  const row = rows[0];
  if (!row) return null;

  if (row.session.role === "participant") {
    if (!row.participant) return null;
    return {
      token,
      role: "participant",
      participantId: row.participant.id,
      name: row.participant.name,
      avatar: row.participant.avatar,
    };
  }

  return {
    token,
    role: "admin",
    participantId: null,
    name: "المشرفة",
    avatar: "👩‍💼",
  };
}

export async function createSession(
  role: SessionRole,
  participantId: string | null,
): Promise<string> {
  const token = `${randomUUID()}${randomUUID()}`.replace(/-/g, "");
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 86_400_000);

  try {
    await db.delete(sessions).where(lt(sessions.expiresAt, new Date()));
  } catch {
    // تجاهل أخطاء تنظيف الجلسات المنتهية
  }

  await db.insert(sessions).values({ token, role, participantId, expiresAt });

  const store = await cookies();
  store.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: SESSION_DAYS * 86_400,
  });

  return token;
}

export async function destroySession(): Promise<void> {
  const store = await cookies();
  const token = store.get(SESSION_COOKIE)?.value;
  if (token) {
    await db.delete(sessions).where(eq(sessions.token, token));
  }
  store.delete(SESSION_COOKIE);
}

export function unauthorized(message = "الجلسة غير صالحة، يرجى تسجيل الدخول.") {
  return Response.json({ ok: false, error: message }, { status: 401 });
}

export function forbidden(message = "هذه الصفحة مخصصة للمشرفة فقط.") {
  return Response.json({ ok: false, error: message }, { status: 403 });
}

export function badRequest(message: string) {
  return Response.json({ ok: false, error: message }, { status: 400 });
}



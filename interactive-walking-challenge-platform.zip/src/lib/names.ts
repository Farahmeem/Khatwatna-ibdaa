import { AVATARS } from "./constants";
import { seededIndex } from "./format";

export function normalizeName(raw: unknown): string | null {
  if (typeof raw !== "string") return null;
  const cleaned = raw
    .replace(/[\u064B-\u0652\u0670]/g, "")
    .replace(/\s+/g, " ")
    .trim();
  if (cleaned.length < 2 || cleaned.length > 40) return null;
  return cleaned;
}

export function nameKeyFor(name: string): string {
  return name.replace(/\s+/g, " ").trim().toLowerCase();
}

export function avatarFor(name: string): string {
  return AVATARS[seededIndex(name.length * 97 + name.charCodeAt(0), AVATARS.length)];
}

import { DOMAINS, type Domain } from "./constants";

export type Question = {
  id: string;
  domain: Domain;
  prompt: string;
  options: string[];
  correctIndex: number;
  explanation: string;
};

const mathQuestions: Question[] = [
  {
    id: "math-1",
    domain: "math",
    prompt: "إذا مشيتِ 2,500 خطوة في الصباح و3,500 خطوة في المساء، فكم خطوة مشيتِ في اليوم؟",
    options: ["5,000 خطوة", "6,000 خطوة", "6,500 خطوة", "7,000 خطوة"],
    correctIndex: 1,
    explanation: "2,500 + 3,500 = 6,000 خطوة.",
  },
  {
    id: "math-2",
    domain: "math",
    prompt: "ما نسبة 10,000 خطوة من الهدف الأسبوعي 70,000 خطوة؟",
    options: ["حوالي 7%", "حوالي 14.3%", "حوالي 20%", "حوالي 70%"],
    correctIndex: 1,
    explanation: "10,000 ÷ 70,000 × 100 ≈ 14.3%.",
  },
  {
    id: "math-3",
    domain: "math",
    prompt: "إذا كانت كل 1,000 خطوة تعادل 0.75 كم، فكم كيلومتراً تقطعين في 10,000 خطوة؟",
    options: ["5 كم", "7.5 كم", "10 كم", "12.5 كم"],
    correctIndex: 1,
    explanation: "10,000 خطوة = 10 × 0.75 = 7.5 كم.",
  },
  {
    id: "math-4",
    domain: "math",
    prompt: "أكملتِ 5 أيام بمعدل 8,000 خطوة يومياً. ما مجموع خطواتكِ؟",
    options: ["32,000 خطوة", "36,000 خطوة", "40,000 خطوة", "45,000 خطوة"],
    correctIndex: 2,
    explanation: "5 × 8,000 = 40,000 خطوة.",
  },
  {
    id: "math-5",
    domain: "math",
    prompt: "هدفكِ اليومي 10,000 خطوة وقد أنجزتِ 7,500 خطوة، فكم خطوة تبقّت؟",
    options: ["2,000 خطوة", "2,500 خطوة", "3,000 خطوة", "3,500 خطوة"],
    correctIndex: 1,
    explanation: "10,000 − 7,500 = 2,500 خطوة.",
  },
  {
    id: "math-6",
    domain: "math",
    prompt: "مشيتِ 9,000 خطوة يومياً لمدة أسبوع كامل (7 أيام). ما إجمالي خطواتكِ؟",
    options: ["54,000 خطوة", "63,000 خطوة", "69,000 خطوة", "72,000 خطوة"],
    correctIndex: 1,
    explanation: "9,000 × 7 = 63,000 خطوة.",
  },
  {
    id: "math-7",
    domain: "math",
    prompt: "كم تساوي 25% من 8,000 خطوة؟",
    options: ["1,500 خطوة", "2,000 خطوة", "2,500 خطوة", "3,000 خطوة"],
    correctIndex: 1,
    explanation: "8,000 × 0.25 = 2,000 خطوة.",
  },
  {
    id: "math-8",
    domain: "math",
    prompt: "مشيتِ 12,000 خطوة اليوم. بكم تجاوزتِ الهدف اليومي 10,000 خطوة؟",
    options: ["1,000 خطوة", "1,500 خطوة", "2,000 خطوة", "3,000 خطوة"],
    correctIndex: 2,
    explanation: "12,000 − 10,000 = 2,000 خطوة إضافية.",
  },
  {
    id: "math-9",
    domain: "math",
    prompt: "ما 10% من الهدف الأسبوعي 70,000 خطوة؟",
    options: ["5,000 خطوة", "7,000 خطوة", "10,000 خطوة", "14,000 خطوة"],
    correctIndex: 1,
    explanation: "70,000 × 0.10 = 7,000 خطوة.",
  },
  {
    id: "math-10",
    domain: "math",
    prompt: "إذا قسمتَ 300 خطوة على 6 مجموعات متساوية، فكم خطوة في كل مجموعة؟",
    options: ["40 خطوة", "45 خطوة", "50 خطوة", "60 خطوة"],
    correctIndex: 2,
    explanation: "300 ÷ 6 = 50 خطوة.",
  },
  {
    id: "math-11",
    domain: "math",
    prompt: "إجمالي خطواتكِ 56,000 خطوة من أصل 70,000. ما نسبة الإنجاز الأسبوعية؟",
    options: ["70%", "75%", "80%", "85%"],
    correctIndex: 2,
    explanation: "56,000 ÷ 70,000 × 100 = 80%.",
  },
];

const arabicQuestions: Question[] = [
  {
    id: "ar-1",
    domain: "arabic",
    prompt: "ما مرادف كلمة «العزيمة»؟",
    options: ["الإصرار", "التعب", "السرعة", "الهدوء"],
    correctIndex: 0,
    explanation: "العزيمة تعني الإصرار وقوة الإرادة.",
  },
  {
    id: "ar-2",
    domain: "arabic",
    prompt: "ما ضد كلمة «الإنجاز»؟",
    options: ["التفوق", "التقصير", "النجاح", "التقدم"],
    correctIndex: 1,
    explanation: "ضد الإنجاز هو التقصير أو التخلف عن الهدف.",
  },
  {
    id: "ar-3",
    domain: "arabic",
    prompt: "ما إعراب الفعل «سعتْ» في: «سعتِ الطالبةُ إلى هدفها»؟",
    options: ["فعل ماضٍ", "فعل مضارع", "اسم فاعل", "فعل أمر"],
    correctIndex: 0,
    explanation: "«سعتْ» فعل ماضٍ مبني على الفتح، والتاء تاء التأنيث الساكنة.",
  },
  {
    id: "ar-4",
    domain: "arabic",
    prompt: "أي الكلمات التالية مكتوبة كتابة صحيحة؟",
    options: ["مسؤولية", "مسؤلية", "مسئوليه", "مسوؤلية"],
    correctIndex: 0,
    explanation: "الصواب «مسؤولية»، فتُكتب الواو بعد الهمزة المفتوحة.",
  },
  {
    id: "ar-5",
    domain: "arabic",
    prompt: "ما جمع كلمة «خطوة»؟",
    options: ["خطوات", "خطاوي", "خطاء", "خطط"],
    correctIndex: 0,
    explanation: "جمع المؤنث السالم لكلمة «خطوة» هو «خطوات».",
  },
  {
    id: "ar-6",
    domain: "arabic",
    prompt: "ما إعراب «هدفي» في: «أنجزتُ هدفي»؟",
    options: ["مفعول به", "فاعل", "مبتدأ", "خبر"],
    correctIndex: 0,
    explanation: "«هدفي» مفعول به منصوب بفتحة مقدرة، والياء مضاف إليه.",
  },
  {
    id: "ar-7",
    domain: "arabic",
    prompt: "ما معنى «نبلغ» في: «بالإصرار نبلغ القمم»؟",
    options: ["نصل إلى", "نترك", "ننسى", "نرفض"],
    correctIndex: 0,
    explanation: "بلوغ الشيء يعني الوصول إليه.",
  },
  {
    id: "ar-8",
    domain: "arabic",
    prompt: "أي مما يلي أسلوب أمر؟",
    options: ["امضي", "تمضي", "مضت", "ستضيف"],
    correctIndex: 0,
    explanation: "«امضي» فعل أمر مبني على حذف حرف العلة.",
  },
  {
    id: "ar-9",
    domain: "arabic",
    prompt: "ما ضد كلمة «التراجع»؟",
    options: ["التقدم", "السكون", "التوقف", "الابتعاد"],
    correctIndex: 0,
    explanation: "التراجع عكس التقدم والنهوض.",
  },
  {
    id: "ar-10",
    domain: "arabic",
    prompt: "ما إعراب «العزيمةَ» في: «إنَّ العزيمةَ تصنع المستحيل»؟",
    options: ["اسم إنّ منصوب", "خبر إنّ مرفوع", "فاعل مرفوع", "مبتدأ مرفوع"],
    correctIndex: 0,
    explanation: "«العزيمةَ» اسم «إنّ» منصوب وعلامة نصبه الفتحة.",
  },
  {
    id: "ar-11",
    domain: "arabic",
    prompt: "أكمل المثل: «بداية الغيث ...»",
    options: ["قطرة", "نقطة", "غيمة", "مطرة"],
    correctIndex: 0,
    explanation: "المثل المشهور: بداية الغيث قطرة.",
  },
];

const englishQuestions: Question[] = [
  {
    id: "en-1",
    domain: "english",
    prompt: "What is the Arabic meaning of «Every step counts»?",
    options: ["كل خطوة لها قيمة", "كل خطوة صعبة", "لا خطوات اليوم", "خطوة واحدة فقط"],
    correctIndex: 0,
    explanation: "«Every step counts» تعني أن كل خطوة تُحسب ولها قيمة وأثر.",
  },
  {
    id: "en-2",
    domain: "english",
    prompt: "Choose the correct translation of «المشي مفيد للصحة»:",
    options: [
      "Walking is good for health",
      "Walking are good for health",
      "Walking good for health",
      "Walking is good at health",
    ],
    correctIndex: 0,
    explanation: "الصيغة الصحيحة: Walking is good for health.",
  },
  {
    id: "en-3",
    domain: "english",
    prompt: "What does «achievement» mean?",
    options: ["إنجاز", "محاولة", "عقبة", "راحة"],
    correctIndex: 0,
    explanation: "Achievement = إنجاز.",
  },
  {
    id: "en-4",
    domain: "english",
    prompt: "Which word means «هدف»?",
    options: ["goal", "step", "walk", "rest"],
    correctIndex: 0,
    explanation: "Goal = هدف.",
  },
  {
    id: "en-5",
    domain: "english",
    prompt: "Complete the sentence: You are ... than you think!",
    options: ["stronger", "strong", "strongest", "more strong"],
    correctIndex: 0,
    explanation: "مع «than» نستخدم صيغة المقارنة: stronger.",
  },
  {
    id: "en-6",
    domain: "english",
    prompt: "What is the meaning of «progress»?",
    options: ["تقدّم", "تراجع", "توقف", "تعب"],
    correctIndex: 0,
    explanation: "Progress = تقدّم.",
  },
  {
    id: "en-7",
    domain: "english",
    prompt: "Choose the correct sentence:",
    options: [
      "She walks 10,000 steps every day.",
      "She walk 10,000 steps every day.",
      "She walking 10,000 steps every day.",
      "She walks 10,000 step every day.",
    ],
    correctIndex: 0,
    explanation: "مع she نضيف s للفعل في المضارع البسيط: walks.",
  },
  {
    id: "en-8",
    domain: "english",
    prompt: "What is «daily» in Arabic?",
    options: ["يومي", "أسبوعي", "شهري", "سنوي"],
    correctIndex: 0,
    explanation: "Daily = يومي.",
  },
  {
    id: "en-9",
    domain: "english",
    prompt: "Which word relates to physical activity?",
    options: ["exercise", "recipe", "library", "chair"],
    correctIndex: 0,
    explanation: "Exercise = تمرين، وهو مرتبط بالنشاط البدني.",
  },
  {
    id: "en-10",
    domain: "english",
    prompt: "Translate: «Small steps lead to big achievements»",
    options: [
      "الخطوات الصغيرة تؤدي إلى إنجازات كبيرة",
      "الخطوات الكبيرة تحتاج وقتاً طويلاً",
      "الإنجاز يأتي بدون خطوات",
      "الخطوات الصغيرة غير مفيدة",
    ],
    correctIndex: 0,
    explanation: "Small steps lead to big achievements = الخطوات الصغيرة تؤدي إلى إنجازات كبيرة.",
  },
  {
    id: "en-11",
    domain: "english",
    prompt: "Choose the correct plural: one step, two ...",
    options: ["steps", "stepes", "steppes", "step"],
    correctIndex: 0,
    explanation: "الجمع الصحيح: steps.",
  },
  {
    id: "en-12",
    domain: "english",
    prompt: "What does «leaderboard» mean?",
    options: ["لوحة المتصدرات", "جدول المهام", "سجل المشاركات", "خطة التحدي"],
    correctIndex: 0,
    explanation: "Leaderboard = لوحة المتصدرات.",
  },
];

export const QUESTION_BANK: Record<Domain, Question[]> = {
  math: mathQuestions,
  arabic: arabicQuestions,
  english: englishQuestions,
};

/**
 * سؤال اليوم: يتناوب بين الرياضيات والعربية والإنجليزية، ويتغير كل أسبوع.
 */
export function getQuestionForDay(weekNumber: number, dayIndex: number): Question {
  const domain = DOMAINS[dayIndex % DOMAINS.length];
  const pool = QUESTION_BANK[domain];
  const index = Math.floor((weekNumber - 1) * 7 + dayIndex) % pool.length;
  return pool[index];
}

export function findQuestionById(questionId: string): Question | null {
  for (const domain of DOMAINS) {
    const found = QUESTION_BANK[domain].find((question) => question.id === questionId);
    if (found) return found;
  }
  return null;
}

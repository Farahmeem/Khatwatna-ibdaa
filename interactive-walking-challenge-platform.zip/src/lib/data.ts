import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import {
  participants,
  quizAnswers,
  settings,
  stepEntries,
  type ChallengeSettings,
  type Participant,
  type QuizAnswer,
  type StepEntry,
} from "@/db/schema";
import { DAILY_GOAL, WEEKLY_GOAL } from "./constants";
import {
  buildBadges,
  getDailyMotivation,
  LEVEL_LABELS,
  levelForPercent,
  pickCelebration,
} from "./content";
import {
  addDays,
  completionPercent,
  dailyPercent,
  diffInDays,
  parseDateKey,
  seedFromString,
  stepsToKm,
  toDateKey,
} from "./format";
import { findQuestionById, getQuestionForDay } from "./questions";
import type {
  AdminData,
  AdminAnswerRow,
  DashboardPayload,
  DayView,
  LeaderboardPayload,
  LeaderboardRow,
  ParticipantSummary,
  WeekInfo,
} from "./types";

const weekdayFormatter = new Intl.DateTimeFormat("ar-EG-u-nu-latn", {
  weekday: "long",
});
const dateFormatter = new Intl.DateTimeFormat("ar-EG-u-nu-latn", {
  day: "numeric",
  month: "long",
});

export async function ensureSettings(): Promise<ChallengeSettings> {
  const existing = await db.select().from(settings).where(eq(settings.id, 1)).limit(1);
  if (existing[0]) return existing[0];

  await db
    .insert(settings)
    .values({ id: 1, weekNumber: 1, weekStart: toDateKey(new Date()) })
    .onConflictDoNothing();

  const created = await db.select().from(settings).where(eq(settings.id, 1)).limit(1);
  return created[0];
}

export function buildWeekInfo(settingsRow: ChallengeSettings): WeekInfo {
  const start = parseDateKey(settingsRow.weekStart);
  const diff = diffInDays(new Date(), start);
  const hasStarted = diff >= 0;
  const hasEnded = diff > 6;
  const currentDayIndex = Math.max(0, Math.min(6, diff));

  const days = Array.from({ length: 7 }, (_, dayIndex) => {
    const date = addDays(start, dayIndex);
    return {
      dayIndex,
      dateKey: toDateKey(date),
      weekday: weekdayFormatter.format(date),
      dateLabel: dateFormatter.format(date),
      isToday: diff === dayIndex,
      isPast: dayIndex < diff,
      isFuture: dayIndex > diff,
    };
  });

  return {
    weekNumber: settingsRow.weekNumber,
    weekStart: settingsRow.weekStart,
    currentDayIndex,
    days,
    hasEnded,
    hasStarted,
    totalDays: 7,
    endDateKey: toDateKey(addDays(start, 6)),
  };
}

export async function getWeekInfo(): Promise<WeekInfo> {
  const settingsRow = await ensureSettings();
  return buildWeekInfo(settingsRow);
}

type RawWeek = {
  people: Participant[];
  steps: StepEntry[];
  answers: QuizAnswer[];
};

async function loadWeek(weekNumber: number): Promise<RawWeek> {
  const [people, steps, answers] = await Promise.all([
    db.select().from(participants).orderBy(asc(participants.createdAt)),
    db.select().from(stepEntries).where(eq(stepEntries.weekNumber, weekNumber)),
    db.select().from(quizAnswers).where(eq(quizAnswers.weekNumber, weekNumber)),
  ]);
  return { people, steps, answers };
}

function buildSummaries(raw: RawWeek, week: WeekInfo): ParticipantSummary[] {
  return raw.people.map((person) => {
    const personSteps = raw.steps.filter((entry) => entry.participantId === person.id);
    const personAnswers = raw.answers.filter((answer) => answer.participantId === person.id);
    const totalSteps = personSteps.reduce((sum, entry) => sum + entry.steps, 0);
    const completedDays = personSteps.filter((entry) => entry.steps >= DAILY_GOAL).length;
    const points = personAnswers.reduce((sum, answer) => sum + answer.points, 0);
    const correctAnswers = personAnswers.filter((answer) => answer.isCorrect).length;
    const todayEntry = personSteps.find((entry) => entry.dayIndex === week.currentDayIndex);

    return {
      id: person.id,
      name: person.name,
      avatar: person.avatar,
      totalSteps,
      km: stepsToKm(totalSteps),
      percent: completionPercent(totalSteps),
      completedDays,
      points,
      correctAnswers,
      answeredCount: personAnswers.length,
      todaySteps: todayEntry?.steps ?? 0,
    };
  });
}

function addRanks(summaries: ParticipantSummary[]): LeaderboardRow[] {
  const bySteps = [...summaries].sort(
    (a, b) => b.totalSteps - a.totalSteps || b.points - a.points || a.name.localeCompare(b.name, "ar"),
  );
  const byPoints = [...summaries].sort(
    (a, b) =>
      b.points - a.points || b.correctAnswers - a.correctAnswers || b.totalSteps - a.totalSteps,
  );

  const stepRank = new Map(bySteps.map((row, index) => [row.id, index + 1]));
  const pointRank = new Map(byPoints.map((row, index) => [row.id, index + 1]));

  return summaries
    .map((row) => ({
      ...row,
      rankSteps: stepRank.get(row.id) ?? summaries.length,
      rankPoints: pointRank.get(row.id) ?? summaries.length,
    }))
    .sort((a, b) => a.rankSteps - b.rankSteps);
}

function buildTotals(summaries: ParticipantSummary[]) {
  return {
    participants: summaries.length,
    steps: summaries.reduce((sum, row) => sum + row.totalSteps, 0),
    km: Math.round(summaries.reduce((sum, row) => sum + row.km, 0) * 10) / 10,
    points: summaries.reduce((sum, row) => sum + row.points, 0),
    completedDays: summaries.reduce((sum, row) => sum + row.completedDays, 0),
    answers: summaries.reduce((sum, row) => sum + row.answeredCount, 0),
  };
}

export async function getLeaderboardData(): Promise<LeaderboardPayload> {
  const week = await getWeekInfo();
  const raw = await loadWeek(week.weekNumber);
  const rows = addRanks(buildSummaries(raw, week));
  return {
    week,
    rows,
    totals: buildTotals(rows),
    generatedAt: new Date().toISOString(),
  };
}

export async function getParticipantById(id: string): Promise<Participant | null> {
  const rows = await db.select().from(participants).where(eq(participants.id, id)).limit(1);
  return rows[0] ?? null;
}

export async function getDashboard(participantId: string): Promise<DashboardPayload | null> {
  const week = await getWeekInfo();
  const raw = await loadWeek(week.weekNumber);
  const person = raw.people.find((p) => p.id === participantId);
  if (!person) return null;

  const summaries = buildSummaries(raw, week);
  const ranked = addRanks(summaries);
  const summary = ranked.find((row) => row.id === participantId) ?? {
    ...buildSummaries(raw, week).find((row) => row.id === participantId)!,
    rankSteps: 0,
    rankPoints: 0,
  };

  const personSteps = raw.steps.filter((entry) => entry.participantId === participantId);
  const personAnswers = raw.answers.filter((answer) => answer.participantId === participantId);
  const seed = seedFromString(participantId);

  const days: DayView[] = week.days.map((day) => {
    const entry = personSteps.find((row) => row.dayIndex === day.dayIndex);
    const answerRecord = personAnswers.find((row) => row.dayIndex === day.dayIndex);
    const question = getQuestionForDay(week.weekNumber, day.dayIndex);
    const steps = entry?.steps ?? 0;
    const isOpen = day.dayIndex <= week.currentDayIndex && week.hasStarted;
    const motivation = getDailyMotivation({
      weekNumber: week.weekNumber,
      dayIndex: day.dayIndex,
      seed,
      percent: completionPercent(summary.totalSteps),
    });

    return {
      dayIndex: day.dayIndex,
      dateKey: day.dateKey,
      weekday: day.weekday,
      dateLabel: day.dateLabel,
      isToday: day.isToday,
      isFuture: day.isFuture,
      steps,
      locked: entry?.locked ?? false,
      celebrated: entry?.celebrated ?? false,
      km: stepsToKm(steps),
      dailyPercent: dailyPercent(steps),
      goalMet: steps >= DAILY_GOAL,
      motivation: {
        domain: motivation.domain,
        text: motivation.text,
        translation: motivation.translation,
        levelLabel: LEVEL_LABELS[motivation.level],
      },
      quiz: {
        available: isOpen,
        isOpen,
        questionId: question.id,
        domain: question.domain,
        prompt: question.prompt,
        options: question.options,
        answer: answerRecord
          ? {
              questionId: answerRecord.questionId,
              domain: answerRecord.domain as DayView["quiz"]["domain"],
              prompt: answerRecord.prompt,
              options: findQuestionById(answerRecord.questionId)?.options ?? [],
              chosenIndex: answerRecord.chosenIndex,
              correctIndex: answerRecord.correctIndex,
              isCorrect: answerRecord.isCorrect,
              points: answerRecord.points,
              explanation:
                findQuestionById(answerRecord.questionId)?.explanation ?? "تم تسجيل إجابتك.",
              answeredAt: answerRecord.answeredAt.toISOString(),
            }
          : null,
      },
    };
  });

  const uncelebrated = personSteps
    .filter((entry) => entry.steps >= DAILY_GOAL && !entry.celebrated)
    .sort((a, b) => b.dayIndex - a.dayIndex)[0];

  const celebrationDay = uncelebrated
    ? {
        dayIndex: uncelebrated.dayIndex,
        text: pickCelebration(seed + uncelebrated.dayIndex * 31 + week.weekNumber),
      }
    : null;

  return {
    participant: { id: person.id, name: person.name, avatar: person.avatar },
    week,
    days,
    summary,
    rankSteps: summary.rankSteps,
    rankPoints: summary.rankPoints,
    participantsCount: ranked.length,
    badges: buildBadges({
      totalSteps: summary.totalSteps,
      completedDays: summary.completedDays,
      points: summary.points,
      correctAnswers: summary.correctAnswers,
      percent: summary.percent,
    }),
    levelLabel: LEVEL_LABELS[levelForPercent(summary.percent)],
    celebration: celebrationDay,
  };
}

export async function getAdminData(): Promise<AdminData> {
  const week = await getWeekInfo();
  const raw = await loadWeek(week.weekNumber);
  const rows = addRanks(buildSummaries(raw, week));
  const totals = buildTotals(rows);
  const correctCount = raw.answers.filter((answer) => answer.isCorrect).length;

  const answers: AdminAnswerRow[] = raw.answers
    .map((answer) => {
      const person = raw.people.find((p) => p.id === answer.participantId);
      const question = findQuestionById(answer.questionId);
      return {
        id: answer.id,
        participantId: answer.participantId,
        participantName: person?.name ?? "مشاركة محذوفة",
        avatar: person?.avatar ?? "👤",
        weekNumber: answer.weekNumber,
        dayIndex: answer.dayIndex,
        domain: answer.domain as AdminAnswerRow["domain"],
        prompt: answer.prompt,
        chosenIndex: answer.chosenIndex,
        correctIndex: answer.correctIndex,
        chosenText: question?.options[answer.chosenIndex] ?? "—",
        correctText: question?.options[answer.correctIndex] ?? "—",
        isCorrect: answer.isCorrect,
        points: answer.points,
        answeredAt: answer.answeredAt.toISOString(),
      };
    })
    .sort((a, b) => (a.answeredAt < b.answeredAt ? 1 : -1));

  const stepsGrid = rows.map((row) => ({
    participantId: row.id,
    participantName: row.name,
    avatar: row.avatar,
    days: week.days.map((day) => {
      const entry = raw.steps.find(
        (item) => item.participantId === row.id && item.dayIndex === day.dayIndex,
      );
      return {
        dayIndex: day.dayIndex,
        steps: entry?.steps ?? 0,
        locked: entry?.locked ?? false,
      };
    }),
  }));

  return {
    week,
    rows,
    answers,
    totals: {
      ...totals,
      correctRate: totals.answers ? (correctCount / totals.answers) * 100 : 0,
    },
    stepsGrid,
  };
}

export const GOALS = { daily: DAILY_GOAL, weekly: WEEKLY_GOAL };

import type { Domain } from "./constants";

export type SessionRole = "participant" | "admin";

export type DayInfo = {
  dayIndex: number;
  dateKey: string;
  weekday: string;
  dateLabel: string;
  isToday: boolean;
  isPast: boolean;
  isFuture: boolean;
};

export type WeekInfo = {
  weekNumber: number;
  weekStart: string;
  currentDayIndex: number;
  days: DayInfo[];
  hasEnded: boolean;
  hasStarted: boolean;
  totalDays: number;
  endDateKey: string;
};

export type AnsweredQuiz = {
  questionId: string;
  domain: Domain;
  prompt: string;
  options: string[];
  chosenIndex: number;
  correctIndex: number;
  isCorrect: boolean;
  points: number;
  explanation: string;
  answeredAt: string;
};

export type QuizView = {
  available: boolean;
  isOpen: boolean;
  questionId: string;
  domain: Domain;
  prompt: string;
  options: string[];
  answer: AnsweredQuiz | null;
};

export type MotivationView = {
  domain: Domain;
  text: string;
  translation?: string;
  levelLabel: string;
};

export type DayView = {
  dayIndex: number;
  dateKey: string;
  weekday: string;
  dateLabel: string;
  isToday: boolean;
  isFuture: boolean;
  steps: number;
  locked: boolean;
  celebrated: boolean;
  km: number;
  dailyPercent: number;
  goalMet: boolean;
  motivation: MotivationView;
  quiz: QuizView;
};

export type ParticipantSummary = {
  id: string;
  name: string;
  avatar: string;
  totalSteps: number;
  km: number;
  percent: number;
  completedDays: number;
  points: number;
  correctAnswers: number;
  answeredCount: number;
  todaySteps: number;
};

export type LeaderboardRow = ParticipantSummary & {
  rankSteps: number;
  rankPoints: number;
};

export type LeaderboardPayload = {
  week: WeekInfo;
  rows: LeaderboardRow[];
  totals: {
    participants: number;
    steps: number;
    km: number;
    points: number;
    completedDays: number;
    answers: number;
  };
  generatedAt: string;
};

export type DashboardPayload = {
  participant: { id: string; name: string; avatar: string };
  week: WeekInfo;
  days: DayView[];
  summary: LeaderboardRow;
  rankSteps: number;
  rankPoints: number;
  participantsCount: number;
  badges: { id: string; title: string; description: string; icon: string; earned: boolean }[];
  levelLabel: string;
  celebration: { dayIndex: number; text: string } | null;
};

export type AdminAnswerRow = {
  id: number;
  participantId: string;
  participantName: string;
  avatar: string;
  weekNumber: number;
  dayIndex: number;
  domain: Domain;
  prompt: string;
  chosenIndex: number;
  correctIndex: number;
  chosenText: string;
  correctText: string;
  isCorrect: boolean;
  points: number;
  answeredAt: string;
};

export type AdminData = {
  week: WeekInfo;
  rows: LeaderboardRow[];
  answers: AdminAnswerRow[];
  totals: {
    participants: number;
    steps: number;
    km: number;
    points: number;
    completedDays: number;
    answers: number;
    correctRate: number;
  };
  stepsGrid: {
    participantId: string;
    participantName: string;
    avatar: string;
    days: { dayIndex: number; steps: number; locked: boolean }[];
  }[];
};

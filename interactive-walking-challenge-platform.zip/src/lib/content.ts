import type { Domain } from "./constants";
import { seededIndex } from "./format";

export type MotivationLevel = "start" | "moving" | "strong" | "champion";

export type Motivation = {
  domain: Domain;
  text: string;
  translation?: string;
  level: MotivationLevel;
};

export const LEVEL_LABELS: Record<MotivationLevel, string> = {
  start: "بداية الطريق",
  moving: "في الطريق",
  strong: "عزيمة متقدة",
  champion: "بطلة الأسبوع",
};

export function levelForPercent(percent: number): MotivationLevel {
  if (percent >= 80) return "champion";
  if (percent >= 50) return "strong";
  if (percent >= 20) return "moving";
  return "start";
}

const englishMessages: Motivation[] = [
  {
    domain: "english",
    text: "Every step counts. Keep moving forward!",
    translation: "كل خطوة لها قيمة… واصلي التقدم للأمام!",
    level: "start",
  },
  {
    domain: "english",
    text: "Small steps lead to big achievements!",
    translation: "الخطوات الصغيرة تصنع إنجازات كبيرة!",
    level: "moving",
  },
  {
    domain: "english",
    text: "You are stronger than you think!",
    translation: "أنتِ أقوى مما تظنين!",
    level: "strong",
  },
  {
    domain: "english",
    text: "Your consistency is your superpower.",
    translation: "استمراريتك هي قوتك الخارقة.",
    level: "moving",
  },
  {
    domain: "english",
    text: "A little progress each day adds up to big results.",
    translation: "تقدم صغير كل يوم يتحول إلى نتائج كبيرة.",
    level: "strong",
  },
  {
    domain: "english",
    text: "Walk with purpose, finish with pride.",
    translation: "امشي بهدف… واصلي بفخر.",
    level: "champion",
  },
];

const mathMessages: Motivation[] = [
  {
    domain: "math",
    text: "هل تعلمين أن 10,000 خطوة تعادل تقريباً 7.5 كم؟",
    level: "start",
  },
  {
    domain: "math",
    text: "كل 1,000 خطوة تقربكِ من إنجاز أكبر!",
    level: "moving",
  },
  {
    domain: "math",
    text: "لقد أنجزتِ 20% من هدفكِ الأسبوعي!",
    level: "moving",
  },
  {
    domain: "math",
    text: "أنتِ الآن عند منتصف الطريق… 50% من الهدف الأسبوعي!",
    level: "strong",
  },
  {
    domain: "math",
    text: "احسبي المسافة التي قطعتِها: اضربي خطواتكِ في 0.00075 لتحصلي على عدد الكيلومترات.",
    level: "start",
  },
  {
    domain: "math",
    text: "أكثر من 80% من الهدف الأسبوعي… أرقامكِ تتحدث عن عزمكِ!",
    level: "champion",
  },
];

const arabicMessages: Motivation[] = [
  {
    domain: "arabic",
    text: "بداية الغيث قطرة، وأول المجد خطوة؛ امضي فإن العزيمة تصنع المستحيل.",
    level: "start",
  },
  {
    domain: "arabic",
    text: "كل خطوة تكتب سطراً جديداً في حكاية نجاحكِ.",
    level: "moving",
  },
  {
    domain: "arabic",
    text: "بالإصرار نبلغ القمم، وبالعزيمة نصنع الفرق.",
    level: "strong",
  },
  {
    domain: "arabic",
    text: "من رام العُلا سهر الليالي… وأنتِ تسعين إليها خطوةً بعد خطوة.",
    level: "strong",
  },
  {
    domain: "arabic",
    text: "إذا كان الشتاءُ يهبّ برداً، فإنّ عزمكِ يهبّ دفئاً وإنجازاً.",
    level: "moving",
  },
  {
    domain: "arabic",
    text: "وما نيلُ المطالبِ بالتمنّي… ولكن تُؤخذُ الدنيا غلابا؛ واصلي حتى القمة.",
    level: "champion",
  },
];

export const MOTIVATION_BANK: Motivation[] = [
  ...englishMessages,
  ...mathMessages,
  ...arabicMessages,
];

/**
 * رسالة اليوم: تختار مجالاً بحسب اليوم، ومستوى الرسالة بحسب نسبة الإنجاز،
 * وتتنوع بحسب معرف المشاركة لمنع التكرار.
 */
export function getDailyMotivation(options: {
  weekNumber: number;
  dayIndex: number;
  seed: number;
  percent: number;
}): Motivation {
  const domain: Domain = (["math", "arabic", "english"] as const)[options.dayIndex % 3];
  const level = levelForPercent(options.percent);
  const exact = MOTIVATION_BANK.filter((m) => m.domain === domain && m.level === level);
  const pool = exact.length
    ? exact
    : MOTIVATION_BANK.filter((m) => m.domain === domain);
  return pool[seededIndex(options.seed + options.weekNumber * 13 + options.dayIndex * 7, pool.length)];
}

export const CELEBRATION_PHRASES = [
  "أحسنتِ! لقد تجاوزتِ حدود التحدي، وحققتِ هدفكِ اليومي!",
  "خطوة بعد خطوة، تصنعين إنجازاً يستحق الفخر!",
  "رائع! 10,000 خطوة من العزيمة والإصرار!",
  "أنتِ اليوم أقرب إلى القمة… واصلِ التوهج!",
  "إنجازكِ اليوم يوقظ النجوم في سماء طموحكِ!",
  "10,000 خطوة… رقمٌ صغير في العدّ، كبيرٌ في المعنى!",
];

export function pickCelebration(seed: number): string {
  return CELEBRATION_PHRASES[seededIndex(seed, CELEBRATION_PHRASES.length)];
}

export type Badge = {
  id: string;
  title: string;
  description: string;
  icon: string;
  earned: boolean;
};

export function buildBadges(options: {
  totalSteps: number;
  completedDays: number;
  points: number;
  correctAnswers: number;
  percent: number;
}): Badge[] {
  const { totalSteps, completedDays, points, correctAnswers, percent } = options;
  return [
    {
      id: "first-step",
      title: "أول خطوة",
      description: "بداية التحدي بأول خطوة مسجّلة",
      icon: "👣",
      earned: totalSteps > 0,
    },
    {
      id: "daily-hero",
      title: "بطلة اليوم",
      description: "تحقيق هدف 10,000 خطوة في يوم واحد",
      icon: "🌟",
      earned: completedDays >= 1,
    },
    {
      id: "half-week",
      title: "منتصف الطريق",
      description: "تحقيق 50% من الهدف الأسبوعي",
      icon: "🚀",
      earned: percent >= 50,
    },
    {
      id: "full-week",
      title: "قمة الأسبوع",
      description: "إكمال الهدف الأسبوعي 70,000 خطوة",
      icon: "🏆",
      earned: totalSteps >= 70_000,
    },
    {
      id: "knowledge",
      title: "عقل متوهج",
      description: "جمع 50 نقطة معرفية",
      icon: "🧠",
      earned: points >= 50,
    },
    {
      id: "scholar",
      title: "عالِمة التحدي",
      description: "الإجابة الصحيحة عن 5 أسئلة",
      icon: "🎓",
      earned: correctAnswers >= 5,
    },
  ];
}

export const HOW_IT_WORKS = [
  {
    icon: "👟",
    title: "سجّلي خطواتكِ يومياً",
    text: "أدخلي عدد خطواتكِ ثم اعتمدي اليوم، ويمكنكِ التعديل قبل الاعتماد.",
  },
  {
    icon: "🧠",
    title: "أجيبي سؤال التحدي",
    text: "سؤال معرفي جديد كل يوم بالتبادل بين الرياضيات والعربية والإنجليزية.",
  },
  {
    icon: "⭐",
    title: "اجمعي النقاط",
    text: "كل إجابة صحيحة تمنحكِ 10 نقاط معرفية منفصلة عن رصيد الخطوات.",
  },
  {
    icon: "🏆",
    title: "تصدّري اللوحة",
    text: "تابعي ترتيبكِ في لوحة المتصدرات للخطوات وللنقاط المعرفية.",
  },
];

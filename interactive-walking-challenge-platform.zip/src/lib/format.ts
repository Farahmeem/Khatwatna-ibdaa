import { DAILY_GOAL, KM_PER_STEP, WEEKLY_GOAL } from "./constants";

export function formatNumber(value: number): string {
  return new Intl.NumberFormat("en-US").format(Math.round(value));
}

export function formatPercent(value: number, digits = 0): string {
  const rounded = Math.round(value * 10 ** digits) / 10 ** digits;
  return `${new Intl.NumberFormat("en-US", {
    minimumFractionDigits: 0,
    maximumFractionDigits: digits,
  }).format(rounded)}%`;
}

export function stepsToKm(steps: number): number {
  return Math.round(steps * KM_PER_STEP * 10) / 10;
}

export function formatKm(steps: number): string {
  return new Intl.NumberFormat("en-US", {
    minimumFractionDigits: 0,
    maximumFractionDigits: 1,
  }).format(stepsToKm(steps));
}

export function completionPercent(totalSteps: number): number {
  return (totalSteps / WEEKLY_GOAL) * 100;
}

export function dailyPercent(steps: number): number {
  return (steps / DAILY_GOAL) * 100;
}

export function clampPercent(value: number): number {
  return Math.max(0, Math.min(100, value));
}

export function toDateKey(date: Date): string {
  const y = date.getFullYear();
  const m = `${date.getMonth() + 1}`.padStart(2, "0");
  const d = `${date.getDate()}`.padStart(2, "0");
  return `${y}-${m}-${d}`;
}

export function parseDateKey(key: string): Date {
  const [y, m, d] = key.split("-").map((part) => Number(part));
  return new Date(y, (m ?? 1) - 1, d ?? 1, 12, 0, 0, 0);
}

export function addDays(date: Date, days: number): Date {
  const next = new Date(date.getTime());
  next.setDate(next.getDate() + days);
  return next;
}

export function startOfDay(date: Date): Date {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate());
}

export function diffInDays(a: Date, b: Date): number {
  return Math.round((startOfDay(a).getTime() - startOfDay(b).getTime()) / 86_400_000);
}

/**
 * رقم زائف ثابت (deterministic) لاختيار الرسائل التحفيزية دون تكرار عشوائي
 */
export function seededIndex(seed: number, length: number): number {
  if (length <= 0) return 0;
  let x = Math.abs(Math.floor(seed)) % 2_147_483_647;
  x = (x ^ 61) ^ (x >>> 16);
  x = x + (x << 3);
  x = x ^ (x >>> 4);
  x = Math.imul(x, 0x27d4eb2d);
  x = x ^ (x >>> 15);
  return Math.abs(x) % length;
}

export function seedFromString(value: string): number {
  let hash = 7;
  for (let i = 0; i < value.length; i += 1) {
    hash = (hash * 31 + value.charCodeAt(i)) % 2_147_483_647;
  }
  return hash;
}

export function formatDateTime(value: Date | string): string {
  const date = typeof value === "string" ? new Date(value) : value;
  return new Intl.DateTimeFormat("ar-EG-u-nu-latn", {
    day: "numeric",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  }).format(date);
}

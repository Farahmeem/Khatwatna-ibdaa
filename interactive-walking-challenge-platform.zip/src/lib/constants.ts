export const DAILY_GOAL = 10_000;
export const WEEKLY_GOAL = 70_000;
export const WEEK_DAYS = 7;
export const KM_PER_STEP = 0.00075;
export const POINTS_PER_CORRECT = 10;

export const DOMAINS = ["math", "arabic", "english"] as const;
export type Domain = (typeof DOMAINS)[number];

export const DOMAIN_LABELS: Record<Domain, string> = {
  math: "الرياضيات",
  arabic: "اللغة العربية",
  english: "اللغة الإنجليزية",
};

export const DOMAIN_ICONS: Record<Domain, string> = {
  math: "📐",
  arabic: "🖋️",
  english: "🔤",
};

export const AVATARS = ["🌸", "🌿", "⭐", "🦋", "🌻", "💎", "🏃‍♀️", "🌟", "🍀", "🕊️"];

export const MEDALS = ["🥇", "🥈", "🥉"];

export const SESSION_COOKIE = "ibdaa_session";
export const SESSION_DAYS = 30;

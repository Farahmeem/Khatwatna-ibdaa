import {
  boolean,
  date,
  index,
  integer,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
  uuid,
} from "drizzle-orm/pg-core";

/**
 * المشاركات في التحدي
 */
export const participants = pgTable("participants", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull(),
  nameKey: text("name_key").notNull().unique(),
  avatar: text("avatar").notNull().default("🌸"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/**
 * جلسات الدخول (مشاركة / مشرفة)
 */
export const sessions = pgTable(
  "sessions",
  {
    token: text("token").primaryKey(),
    role: text("role").notNull(), // participant | admin
    participantId: uuid("participant_id").references(() => participants.id, {
      onDelete: "cascade",
    }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  },
  (table) => [index("sessions_participant_idx").on(table.participantId)],
);

/**
 * إعدادات التحدي (أسبوع التحدي الحالي)
 */
export const settings = pgTable("settings", {
  id: integer("id").primaryKey(),
  weekNumber: integer("week_number").notNull().default(1),
  weekStart: date("week_start").notNull(),
  title: text("title").notNull().default("خطواتنا إبداع"),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

/**
 * خطوات كل يوم لكل مشاركة
 */
export const stepEntries = pgTable(
  "step_entries",
  {
    id: serial("id").primaryKey(),
    participantId: uuid("participant_id")
      .notNull()
      .references(() => participants.id, { onDelete: "cascade" }),
    weekNumber: integer("week_number").notNull(),
    dayIndex: integer("day_index").notNull(), // 0..6
    steps: integer("steps").notNull().default(0),
    locked: boolean("locked").notNull().default(false),
    celebrated: boolean("celebrated").notNull().default(false),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    uniqueIndex("step_entries_unique_idx").on(
      table.participantId,
      table.weekNumber,
      table.dayIndex,
    ),
  ],
);

/**
 * إجابات التحدي المعرفي اليومي
 */
export const quizAnswers = pgTable(
  "quiz_answers",
  {
    id: serial("id").primaryKey(),
    participantId: uuid("participant_id")
      .notNull()
      .references(() => participants.id, { onDelete: "cascade" }),
    weekNumber: integer("week_number").notNull(),
    dayIndex: integer("day_index").notNull(),
    questionId: text("question_id").notNull(),
    domain: text("domain").notNull(), // math | arabic | english
    prompt: text("prompt").notNull(),
    chosenIndex: integer("chosen_index").notNull(),
    correctIndex: integer("correct_index").notNull(),
    isCorrect: boolean("is_correct").notNull(),
    points: integer("points").notNull().default(0),
    answeredAt: timestamp("answered_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    uniqueIndex("quiz_answers_unique_idx").on(
      table.participantId,
      table.weekNumber,
      table.dayIndex,
    ),
    index("quiz_answers_participant_idx").on(table.participantId),
  ],
);

export type Participant = typeof participants.$inferSelect;
export type StepEntry = typeof stepEntries.$inferSelect;
export type QuizAnswer = typeof quizAnswers.$inferSelect;
export type ChallengeSettings = typeof settings.$inferSelect;

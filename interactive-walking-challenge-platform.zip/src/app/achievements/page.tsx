import Link from "next/link";
import { redirect } from "next/navigation";
import PrintButton from "@/components/PrintButton";
import { DomainBadge, ProgressBar } from "@/components/ui";
import { DAILY_GOAL, WEEKLY_GOAL } from "@/lib/constants";
import { getDashboard } from "@/lib/data";
import {
  formatDateTime,
  formatKm,
  formatNumber,
  formatPercent,
} from "@/lib/format";
import { getAuthUser } from "@/lib/session";

export const dynamic = "force-dynamic";

export default async function AchievementsPage() {
  const user = await getAuthUser();

  if (!user) redirect("/login");
  if (user.role === "admin") redirect("/admin");
  if (!user.participantId) redirect("/login");

  const data = await getDashboard(user.participantId);
  if (!data) redirect("/login");

  const { summary, days, week } = data;
  const lastAnswer = [...days]
    .filter((day) => day.quiz.answer)
    .sort((a, b) =>
      (a.quiz.answer?.answeredAt ?? "") < (b.quiz.answer?.answeredAt ?? "") ? 1 : -1,
    )[0]?.quiz.answer;

  const radius = 54;
  const circumference = 2 * Math.PI * radius;
  const ringValue = Math.min(100, summary.percent);
  const offset = circumference - (ringValue / 100) * circumference;

  const facts = [
    { label: "إجمالي الخطوات", value: `${formatNumber(summary.totalSteps)}`, unit: "خطوة", icon: "👟" },
    { label: "الكيلومترات التقريبية", value: formatKm(summary.totalSteps), unit: "كم", icon: "📍" },
    { label: "نسبة الإنجاز الأسبوعية", value: formatPercent(summary.percent, 1), unit: "", icon: "📊" },
    { label: "الأيام المكتملة", value: `${summary.completedDays}`, unit: "من 7", icon: "✅" },
    { label: "النقاط المعرفية", value: `${formatNumber(summary.points)}`, unit: "نقطة", icon: "🧠" },
    { label: "الإجابات الصحيحة", value: `${summary.correctAnswers}`, unit: "إجابة", icon: "🎯" },
  ];

  return (
    <div className="mx-auto max-w-5xl px-4 py-8">
      <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
        <div>
          <span className="chip chip-gold">🏅 بطاقة الإنجاز الشخصية</span>
          <h1 className="mt-2 text-3xl font-extrabold text-brand-900">إنجازاتي</h1>
          <p className="mt-1 text-sm text-ink-500">
            أسبوع التحدي {week.weekNumber} · {week.days[0].weekday} {week.days[0].dateLabel} —{" "}
            {week.days[6].weekday} {week.days[6].dateLabel}
          </p>
        </div>
        <div className="no-print flex flex-wrap gap-2">
          <PrintButton />
          <Link href="/dashboard" className="btn btn-primary !py-2 !text-xs">
            👟 متابعة التحدي
          </Link>
        </div>
      </div>

      <section className="card overflow-hidden">
        <div className="relative bg-gradient-to-br from-brand-700 via-brand-600 to-brand-800 px-5 py-6 text-white sm:px-8">
          <div className="pattern-dots absolute inset-0 opacity-20" />
          <div className="relative flex flex-wrap items-center justify-between gap-6">
            <div className="flex items-center gap-4">
              <span className="grid h-20 w-20 place-items-center rounded-3xl bg-white/15 text-4xl backdrop-blur-sm">
                {data.participant.avatar}
              </span>
              <div>
                <p className="text-xs font-bold text-brand-100">مشاركة في تحدي خطواتنا إبداع</p>
                <h2 className="text-2xl font-extrabold sm:text-3xl">{data.participant.name}</h2>
                <div className="mt-2 flex flex-wrap gap-1.5">
                  <span className="chip border-white/30 bg-white/15 text-white">
                    🏅 {data.levelLabel}
                  </span>
                  <span className="chip border-white/30 bg-white/15 text-white">
                    👟 المركز {data.rankSteps} من {data.participantsCount}
                  </span>
                  <span className="chip border-white/30 bg-white/15 text-white">
                    🧠 المركز {data.rankPoints} معرفياً
                  </span>
                </div>
              </div>
            </div>

            <div className="relative grid h-36 w-36 place-items-center">
              <svg viewBox="0 0 140 140" className="h-36 w-36 -rotate-90">
                <circle cx="70" cy="70" r={radius} fill="none" stroke="rgba(255,255,255,0.22)" strokeWidth="12" />
                <circle
                  cx="70"
                  cy="70"
                  r={radius}
                  fill="none"
                  stroke="#f2d98b"
                  strokeWidth="12"
                  strokeLinecap="round"
                  strokeDasharray={circumference}
                  strokeDashoffset={offset}
                />
              </svg>
              <div className="absolute text-center">
                <p className="text-2xl font-extrabold">{formatPercent(summary.percent, 1)}</p>
                <p className="text-[10px] font-bold text-brand-100">من الهدف الأسبوعي</p>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3 p-4 sm:grid-cols-3 sm:p-6">
          {facts.map((fact) => (
            <div key={fact.label} className="rounded-2xl border border-brand-100 bg-brand-50/40 p-3">
              <p className="text-[11px] font-bold text-ink-500">
                {fact.icon} {fact.label}
              </p>
              <p className="mt-1 text-xl font-extrabold text-brand-900">
                {fact.value}{" "}
                <span className="text-[10px] font-bold text-ink-500">{fact.unit}</span>
              </p>
            </div>
          ))}
        </div>

        <div className="border-t border-brand-100 px-4 py-5 sm:px-6">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h3 className="text-sm font-extrabold text-brand-900">شريط التقدم الأسبوعي</h3>
            <span className="chip">
              {formatNumber(summary.totalSteps)} / {formatNumber(WEEKLY_GOAL)} خطوة
            </span>
          </div>
          <ProgressBar value={summary.percent} className="mt-3" height="h-4" />
          <div className="mt-2 flex justify-between text-[11px] font-bold text-ink-500">
            <span>الهدف اليومي {formatNumber(DAILY_GOAL)} خطوة</span>
            <span>الهدف الأسبوعي {formatNumber(WEEKLY_GOAL)} خطوة</span>
          </div>
        </div>
      </section>

      <section className="mt-6 grid gap-4 lg:grid-cols-2">
        <div className="card p-5">
          <h3 className="flex items-center gap-2 text-lg font-extrabold text-brand-900">
            🧠 آخر سؤال تمت الإجابة عنه
          </h3>
          {lastAnswer ? (
            <div className="mt-3">
              <DomainBadge domain={lastAnswer.domain} />
              <p className="mt-2 text-sm font-bold leading-6 text-ink-700">{lastAnswer.prompt}</p>
              <div className="mt-2 space-y-1.5">
                <p
                  className={`rounded-xl px-3 py-2 text-xs font-bold ${
                    lastAnswer.isCorrect
                      ? "bg-brand-50 text-brand-800"
                      : "bg-rose-50 text-rose-700"
                  }`}
                >
                  إجابتكِ: {lastAnswer.options[lastAnswer.chosenIndex] ?? "—"}{" "}
                  {lastAnswer.isCorrect ? "✅" : "❌"}
                </p>
                {!lastAnswer.isCorrect ? (
                  <p className="rounded-xl bg-brand-50 px-3 py-2 text-xs font-bold text-brand-800">
                    الإجابة الصحيحة: {lastAnswer.options[lastAnswer.correctIndex]}
                  </p>
                ) : null}
                <p className="rounded-xl bg-gold-50 px-3 py-2 text-xs font-medium leading-5 text-gold-600">
                  💡 {lastAnswer.explanation}
                </p>
              </div>
              <p className="mt-2 text-[10px] font-medium text-ink-500">
                {formatDateTime(lastAnswer.answeredAt)} · {lastAnswer.points} نقاط
              </p>
            </div>
          ) : (
            <p className="mt-3 rounded-xl bg-brand-50/70 px-3 py-6 text-center text-sm font-bold text-ink-500">
              لم تجيبي عن أي سؤال بعد. ابدئي بسؤال اليوم من لوحة التحدي 🧠
            </p>
          )}
        </div>

        <div className="card p-5">
          <h3 className="flex items-center gap-2 text-lg font-extrabold text-brand-900">
            ⭐ شارات الإنجاز
          </h3>
          <div className="mt-3 grid grid-cols-2 gap-2">
            {data.badges.map((badge) => (
              <div
                key={badge.id}
                className={`rounded-2xl border px-3 py-2.5 ${
                  badge.earned
                    ? "border-gold-200 bg-gold-50 text-gold-600"
                    : "border-brand-100 bg-white text-ink-500 opacity-70"
                }`}
              >
                <p className="text-lg">{badge.icon}</p>
                <p className="text-xs font-extrabold">{badge.title}</p>
                <p className="text-[10px] leading-4">{badge.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="card mt-6 p-5">
        <h3 className="text-lg font-extrabold text-brand-900">📅 تفاصيل أيام الأسبوع</h3>
        <div className="mt-3 grid gap-2 sm:grid-cols-2">
          {days.map((day) => (
            <div
              key={day.dayIndex}
              className={`flex items-center justify-between gap-2 rounded-2xl border px-3 py-2.5 ${
                day.goalMet ? "border-brand-200 bg-brand-50" : "border-brand-100 bg-white"
              }`}
            >
              <div>
                <p className="text-xs font-extrabold text-brand-900">
                  {day.weekday} · {day.dateLabel}
                </p>
                <p className="text-[10px] font-medium text-ink-500">
                  {formatNumber(day.steps)} خطوة · {formatKm(day.steps)} كم
                  {day.quiz.answer?.isCorrect ? " · 🧠 إجابة صحيحة" : ""}
                </p>
              </div>
              <span className={`chip ${day.goalMet ? "" : "chip-gold"}`}>
                {day.goalMet ? `✅ ${formatPercent(day.dailyPercent)}` : day.quiz.answer ? "تمت الإجابة" : "بانتظاركِ"}
              </span>
            </div>
          ))}
        </div>
      </section>

      <p className="mt-6 rounded-2xl border border-gold-200 bg-gold-50 px-4 py-3 text-center text-sm font-bold leading-7 text-gold-600">
        «كل خطوة تكتب سطراً جديداً في حكاية نجاحكِ» — استمري، فالقمم تُبلغ بالعزيمة 🌿
      </p>
    </div>
  );
}

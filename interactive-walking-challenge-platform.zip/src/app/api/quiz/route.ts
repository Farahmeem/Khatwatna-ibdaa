import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { quizAnswers } from "@/db/schema";
import { POINTS_PER_CORRECT } from "@/lib/constants";
import { getWeekInfo } from "@/lib/data";
import { getQuestionForDay } from "@/lib/questions";
import { badRequest, getAuthUser, unauthorized } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const user = await getAuthUser();
  if (!user || user.role !== "participant" || !user.participantId) {
    return unauthorized("يجب تسجيل الدخول كمشاركة للإجابة عن سؤال التحدي.");
  }

  const body = (await request.json().catch(() => null)) as {
    dayIndex?: unknown;
    chosenIndex?: unknown;
  } | null;

  const dayIndex = Number(body?.dayIndex);
  const chosenIndex = Number(body?.chosenIndex);

  if (!Number.isInteger(dayIndex) || dayIndex < 0 || dayIndex > 6) {
    return badRequest("اليوم المحدد غير صحيح.");
  }

  if (!Number.isInteger(chosenIndex) || chosenIndex < 0 || chosenIndex > 8) {
    return badRequest("يرجى اختيار إجابة صحيحة.");
  }

  const week = await getWeekInfo();

  if (!week.hasStarted || dayIndex > week.currentDayIndex) {
    return badRequest("لم يُفتح سؤال هذا اليوم بعد. عودي في يومه!");
  }

  const participantId = user.participantId;
  const question = getQuestionForDay(week.weekNumber, dayIndex);

  if (chosenIndex >= question.options.length) {
    return badRequest("خيار الإجابة غير متاح لهذا السؤال.");
  }

  const already = await db
    .select()
    .from(quizAnswers)
    .where(
      and(
        eq(quizAnswers.participantId, participantId),
        eq(quizAnswers.weekNumber, week.weekNumber),
        eq(quizAnswers.dayIndex, dayIndex),
      ),
    )
    .limit(1);

  if (already[0]) {
    return Response.json(
      {
        ok: false,
        error: "تم تسجيل إجابتك عن سؤال هذا اليوم مسبقاً، ولا يمكن احتساب النقاط أكثر من مرة.",
        answer: already[0],
      },
      { status: 409 },
    );
  }

  const isCorrect = chosenIndex === question.correctIndex;
  const points = isCorrect ? POINTS_PER_CORRECT : 0;

  try {
    const inserted = await db
      .insert(quizAnswers)
      .values({
        participantId,
        weekNumber: week.weekNumber,
        dayIndex,
        questionId: question.id,
        domain: question.domain,
        prompt: question.prompt,
        chosenIndex,
        correctIndex: question.correctIndex,
        isCorrect,
        points,
      })
      .returning();

    return Response.json({
      ok: true,
      isCorrect,
      chosenIndex,
      correctIndex: question.correctIndex,
      explanation: question.explanation,
      points,
      correctText: question.options[question.correctIndex],
      answer: inserted[0],
    });
  } catch {
    return Response.json(
      {
        ok: false,
        error: "تم تسجيل إجابتك عن سؤال هذا اليوم مسبقاً.",
      },
      { status: 409 },
    );
  }
}

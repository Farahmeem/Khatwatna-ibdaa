import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { stepEntries } from "@/db/schema";
import { DAILY_GOAL } from "@/lib/constants";
import { pickCelebration } from "@/lib/content";
import { getWeekInfo } from "@/lib/data";
import { dailyPercent, seedFromString, stepsToKm } from "@/lib/format";
import { badRequest, getAuthUser, unauthorized } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const user = await getAuthUser();
  if (!user || user.role !== "participant" || !user.participantId) {
    return unauthorized("يجب تسجيل الدخول كمشاركة لتحديث الخطوات.");
  }

  const body = (await request.json().catch(() => null)) as {
    dayIndex?: unknown;
    steps?: unknown;
    action?: unknown;
  } | null;

  const dayIndex = Number(body?.dayIndex);
  const action = typeof body?.action === "string" ? body.action : "save";

  if (!Number.isInteger(dayIndex) || dayIndex < 0 || dayIndex > 6) {
    return badRequest("اليوم المحدد غير صحيح.");
  }

  const week = await getWeekInfo();
  const participantId = user.participantId;

  if (action === "celebrate") {
    await db
      .update(stepEntries)
      .set({ celebrated: true })
      .where(
        and(
          eq(stepEntries.participantId, participantId),
          eq(stepEntries.weekNumber, week.weekNumber),
          eq(stepEntries.dayIndex, dayIndex),
        ),
      );
    return Response.json({ ok: true });
  }

  const steps = Number(body?.steps);
  if (!Number.isFinite(steps) || steps < 0 || steps > 200_000 || !Number.isInteger(steps)) {
    return badRequest("عدد الخطوات يجب أن يكون رقماً صحيحاً بين 0 و200,000.");
  }

  if (action !== "save" && action !== "lock") {
    return badRequest("إجراء غير معروف.");
  }

  const existing = await db
    .select()
    .from(stepEntries)
    .where(
      and(
        eq(stepEntries.participantId, participantId),
        eq(stepEntries.weekNumber, week.weekNumber),
        eq(stepEntries.dayIndex, dayIndex),
      ),
    )
    .limit(1);

  const current = existing[0];

  if (current?.locked) {
    return Response.json(
      {
        ok: false,
        error: "تم اعتماد هذا اليوم ولا يمكن تعديله. يمكنكِ التواصل مع المشرفة.",
      },
      { status: 409 },
    );
  }

  const locked = action === "lock";

  await db
    .insert(stepEntries)
    .values({
      participantId,
      weekNumber: week.weekNumber,
      dayIndex,
      steps,
      locked,
      celebrated: false,
    })
    .onConflictDoUpdate({
      target: [stepEntries.participantId, stepEntries.weekNumber, stepEntries.dayIndex],
      set: { steps, locked, updatedAt: new Date() },
    });

  const shouldCelebrate = steps >= DAILY_GOAL && !current?.celebrated;

  return Response.json({
    ok: true,
    entry: {
      dayIndex,
      steps,
      locked,
      km: stepsToKm(steps),
      dailyPercent: dailyPercent(steps),
    },
    celebrate: shouldCelebrate
      ? {
          dayIndex,
          text: pickCelebration(
            seedFromString(participantId) + dayIndex * 31 + week.weekNumber * 7,
          ),
        }
      : null,
  });
}

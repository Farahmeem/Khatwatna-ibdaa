import { getDashboard } from "@/lib/data";
import { getAuthUser, unauthorized } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function GET() {
  const user = await getAuthUser();
  if (!user || user.role !== "participant" || !user.participantId) {
    return unauthorized("يجب تسجيل الدخول كمشاركة.");
  }

  const payload = await getDashboard(user.participantId);
  if (!payload) {
    return Response.json({ ok: false, error: "لم يتم العثور على ملف المشاركة." }, { status: 404 });
  }

  return Response.json(payload, { headers: { "Cache-Control": "no-store" } });
}

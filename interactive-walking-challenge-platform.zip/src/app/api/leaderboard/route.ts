import { getLeaderboardData } from "@/lib/data";

export const dynamic = "force-dynamic";

export async function GET() {
  const payload = await getLeaderboardData();
  return Response.json(payload, {
    headers: { "Cache-Control": "no-store" },
  });
}

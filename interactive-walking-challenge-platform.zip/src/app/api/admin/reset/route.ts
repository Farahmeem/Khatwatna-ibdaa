import { eq } from "drizzle-orm";
import { db } from "@/db";
import { quizAnswers, settings, stepEntries } from "@/db/schema";
import { buildWeekInfo, ensureSettings } from "@/lib/data";
import { toDateKey } from "@/lib/format";
import { badRequest, forbidden, getAuthUser, unauthorized } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const user = await getAuthUser();
  if (!user) return unauthorized();
  if (user.role !== "admin") return forbidden();

  const body = (await request.json().catch(() => null)) as { action?: unknown } | null;
  const action = typeof body?.action === "string" ? body.action : "";
  const current = await ensureSettings();

  if (action === "new-week") {
    const updated = await db
      .update(settings)
      .set({
        weekNumber: current.weekNumber + 1,
        weekStart: toDateKey(new Date()),
        updatedAt: new Date(),
      })
      .where(eq(settings.id, 1))
      .returning();

    return Response.json({
      ok: true,
      message: `تم بدء الأسبوع رقم ${updated[0].weekNumber}. النتائج السابقة محفوظة في أرشيف الأسابيع.`,
      week: buildWeekInfo(updated[0]),
    });
  }

  if (action === "clear-week") {
    await db.delete(stepEntries).where(eq(stepEntries.weekNumber, current.weekNumber));
    await db.delete(quizAnswers).where(eq(quizAnswers.weekNumber, current.weekNumber));

    return Response.json({
      ok: true,
      message: `تم تفريغ بيانات الأسبوع الحالي (${current.weekNumber}) مع بقاء المشاركات.`,
    });
  }

  return badRequest("إجراء غير معروف.");
}

import { getAdminData, getWeekInfo } from "@/lib/data";
import { formatPercent } from "@/lib/format";
import { getAuthUser, unauthorized, forbidden } from "@/lib/session";

export const dynamic = "force-dynamic";

function csvCell(value: string | number): string {
  const text = `${value}`.replace(/"/g, '""');
  return `"${text}"`;
}

export async function GET(request: Request) {
  const user = await getAuthUser();
  if (!user) return unauthorized();
  if (user.role !== "admin") return forbidden();

  const type = new URL(request.url).searchParams.get("type") ?? "summary";
  const week = await getWeekInfo();
  const admin = await getAdminData();
  const lines: string[] = [];

  if (type === "answers") {
    lines.push(
      [
        "الأسبوع",
        "اليوم",
        "المشاركة",
        "المجال",
        "السؤال",
        "الإجابة المختارة",
        "الإجابة الصحيحة",
        "النتيجة",
        "النقاط",
        "وقت الإجابة",
      ]
        .map(csvCell)
        .join(","),
    );

    for (const answer of admin.answers) {
      lines.push(
        [
          answer.weekNumber,
          answer.dayIndex + 1,
          answer.participantName,
          answer.domain,
          answer.prompt,
          answer.chosenText,
          answer.correctText,
          answer.isCorrect ? "صحيحة" : "خاطئة",
          answer.points,
          new Date(answer.answeredAt).toLocaleString("ar-EG"),
        ]
          .map(csvCell)
          .join(","),
      );
    }
  } else {
    const headers = [
      "المركز",
      "الاسم",
      "إجمالي الخطوات",
      "الكيلومترات",
      "نسبة الإنجاز",
      "الأيام المكتملة",
      "نقاط المعرفة",
      "إجابات صحيحة",
      "عدد الأسئلة المجابة",
      ...week.days.map((day) => `اليوم ${day.dayIndex + 1} (${day.weekday})`),
    ];
    lines.push(headers.map(csvCell).join(","));

    for (const row of admin.rows) {
      const grid = admin.stepsGrid.find((item) => item.participantId === row.id);
      lines.push(
        [
          row.rankSteps,
          row.name,
          row.totalSteps,
          row.km,
          formatPercent(row.percent, 1),
          row.completedDays,
          row.points,
          row.correctAnswers,
          row.answeredCount,
          ...week.days.map((day) => grid?.days.find((d) => d.dayIndex === day.dayIndex)?.steps ?? 0),
        ]
          .map(csvCell)
          .join(","),
      );
    }
  }

  const csv = `\uFEFF${lines.join("\r\n")}`;
  const filename = `khutuwatuna-ibdaa-week-${week.weekNumber}-${type}.csv`;

  return new Response(csv, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="${filename}"`,
      "Cache-Control": "no-store",
    },
  });
}

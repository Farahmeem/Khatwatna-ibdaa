import { getAdminData } from "@/lib/data";
import { forbidden, getAuthUser, unauthorized } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function GET() {
  const user = await getAuthUser();
  if (!user) return unauthorized();
  if (user.role !== "admin") return forbidden();

  const payload = await getAdminData();
  return Response.json(payload, { headers: { "Cache-Control": "no-store" } });
}

import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { participants, stepEntries } from "@/db/schema";
import { DAILY_GOAL } from "@/lib/constants";
import { getWeekInfo } from "@/lib/data";
import { badRequest, forbidden, getAuthUser, unauthorized } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const user = await getAuthUser();
  if (!user) return unauthorized();
  if (user.role !== "admin") return forbidden();

  const body = (await request.json().catch(() => null)) as {
    participantId?: unknown;
    dayIndex?: unknown;
    steps?: unknown;
    locked?: unknown;
  } | null;

  const participantId = typeof body?.participantId === "string" ? body.participantId : "";
  const dayIndex = Number(body?.dayIndex);
  const steps = Number(body?.steps);

  if (!participantId) return badRequest("معرّف المشاركة مطلوب.");
  if (!Number.isInteger(dayIndex) || dayIndex < 0 || dayIndex > 6) {
    return badRequest("اليوم المحدد غير صحيح.");
  }
  if (!Number.isInteger(steps) || steps < 0 || steps > 200_000) {
    return badRequest("عدد الخطوات يجب أن يكون رقماً صحيحاً بين 0 و200,000.");
  }

  const exists = await db
    .select({ id: participants.id })
    .from(participants)
    .where(eq(participants.id, participantId))
    .limit(1);

  if (!exists[0]) return badRequest("لم يتم العثور على المشاركة.");

  const week = await getWeekInfo();
  const locked = body?.locked === true;

  const saved = await db
    .insert(stepEntries)
    .values({
      participantId,
      weekNumber: week.weekNumber,
      dayIndex,
      steps,
      locked,
      celebrated: steps >= DAILY_GOAL,
    })
    .onConflictDoUpdate({
      target: [stepEntries.participantId, stepEntries.weekNumber, stepEntries.dayIndex],
      set: {
        steps,
        locked,
        celebrated: steps >= DAILY_GOAL,
        updatedAt: new Date(),
      },
    })
    .returning();

  const record = await db
    .select()
    .from(stepEntries)
    .where(
      and(
        eq(stepEntries.participantId, participantId),
        eq(stepEntries.weekNumber, week.weekNumber),
        eq(stepEntries.dayIndex, dayIndex),
      ),
    )
    .limit(1);

  return Response.json({ ok: true, entry: record[0] ?? saved[0] });
}

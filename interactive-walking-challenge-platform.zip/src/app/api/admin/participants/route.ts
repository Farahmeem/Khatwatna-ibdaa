import { eq } from "drizzle-orm";
import { db } from "@/db";
import { participants } from "@/db/schema";
import { avatarFor, nameKeyFor, normalizeName } from "@/lib/names";
import { badRequest, forbidden, getAuthUser, unauthorized } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const user = await getAuthUser();
  if (!user) return unauthorized();
  if (user.role !== "admin") return forbidden();

  const body = (await request.json().catch(() => null)) as {
    action?: unknown;
    name?: unknown;
    participantId?: unknown;
  } | null;

  const action = typeof body?.action === "string" ? body.action : "";

  if (action === "create") {
    const name = normalizeName(body?.name);
    if (!name) return badRequest("يرجى إدخال اسم صحيح بين 2 و40 حرفاً.");

    const inserted = await db
      .insert(participants)
      .values({ name, nameKey: nameKeyFor(name), avatar: avatarFor(name) })
      .onConflictDoNothing()
      .returning();

    if (!inserted[0]) {
      return Response.json(
        { ok: false, error: "هذا الاسم مسجّل مسبقاً في التحدي." },
        { status: 409 },
      );
    }

    return Response.json({ ok: true, participant: inserted[0] });
  }

  const participantId = typeof body?.participantId === "string" ? body.participantId : "";

  if (!participantId) return badRequest("معرّف المشاركة مطلوب.");

  if (action === "rename") {
    const name = normalizeName(body?.name);
    if (!name) return badRequest("يرجى إدخال اسم صحيح بين 2 و40 حرفاً.");

    const updated = await db
      .update(participants)
      .set({ name, nameKey: nameKeyFor(name) })
      .where(eq(participants.id, participantId))
      .returning();

    if (!updated[0]) return badRequest("لم يتم العثور على المشاركة.");

    return Response.json({ ok: true, participant: updated[0] });
  }

  if (action === "delete") {
    await db.delete(participants).where(eq(participants.id, participantId));
    return Response.json({ ok: true });
  }

  return badRequest("إجراء غير معروف.");
}

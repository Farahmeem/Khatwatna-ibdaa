import { eq } from "drizzle-orm";
import { db } from "@/db";
import { participants } from "@/db/schema";
import { avatarFor, nameKeyFor, normalizeName } from "@/lib/names";
import { badRequest, createSession } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const body = (await request.json().catch(() => null)) as { name?: unknown } | null;
  const name = normalizeName(body?.name);

  if (!name) {
    return badRequest("يرجى إدخال اسم صحيح بين 2 و40 حرفاً.");
  }

  const nameKey = nameKeyFor(name);
  const existing = await db
    .select()
    .from(participants)
    .where(eq(participants.nameKey, nameKey))
    .limit(1);

  let person = existing[0];

  if (!person) {
    const inserted = await db
      .insert(participants)
      .values({ name, nameKey, avatar: avatarFor(name) })
      .onConflictDoNothing()
      .returning();

    person =
      inserted[0] ??
      (
        await db.select().from(participants).where(eq(participants.nameKey, nameKey)).limit(1)
      )[0];
  }

  if (!person) {
    return badRequest("تعذّر إنشاء الحساب، حاولي مرة أخرى.");
  }

  await createSession("participant", person.id);

  return Response.json({
    ok: true,
    participant: { id: person.id, name: person.name, avatar: person.avatar },
    returning: existing.length > 0,
  });
}

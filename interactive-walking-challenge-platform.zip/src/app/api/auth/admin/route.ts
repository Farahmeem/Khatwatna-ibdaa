import { badRequest, createSession, getAdminPassword } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const body = (await request.json().catch(() => null)) as { password?: unknown } | null;
  const password = typeof body?.password === "string" ? body.password.trim() : "";

  if (!password) {
    return badRequest("يرجى إدخال كلمة مرور المشرفة.");
  }

  if (password !== getAdminPassword()) {
    return Response.json({ ok: false, error: "كلمة المرور غير صحيحة." }, { status: 401 });
  }

  await createSession("admin", null);
  return Response.json({ ok: true });
}

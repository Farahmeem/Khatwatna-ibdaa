import Link from "next/link";
import AdminClient from "@/components/AdminClient";
import LoginForm from "@/components/LoginForm";
import { getAdminData } from "@/lib/data";
import { getAuthUser } from "@/lib/session";

export const dynamic = "force-dynamic";

export default async function AdminPage() {
  const user = await getAuthUser();

  if (!user || user.role !== "admin") {
    return (
      <div className="mx-auto max-w-xl px-4 py-12">
        <div className="mb-5 text-center">
          <span className="text-4xl">👩‍💼</span>
          <h1 className="mt-2 text-2xl font-extrabold text-brand-900">لوحة تحكم المشرفة</h1>
          <p className="mt-1 text-sm text-ink-500">
            إدارة المشاركات، الخطوات، الإجابات، إعادة ضبط التحدي وتصدير النتائج.
          </p>
        </div>

        {user?.role === "participant" ? (
          <div className="mb-4 rounded-2xl border border-gold-200 bg-gold-50 px-4 py-3 text-center text-xs font-bold leading-6 text-gold-600">
            أنتِ مسجّلة الآن كمشاركة ({user.name}). للدخول إلى صلاحيات المشرفة سجّلي الخروج أولاً
            من زر «خروج» في الأعلى ثم أدخلي كلمة المرور.
            <div className="mt-2">
              <Link href="/dashboard" className="btn btn-soft !py-1.5 !text-xs">
                العودة إلى لوحتي
              </Link>
            </div>
          </div>
        ) : null}

        <LoginForm existingNames={[]} isAdminPasswordDefault={!process.env.ADMIN_PASSWORD} defaultMode="admin" />
      </div>
    );
  }

  const data = await getAdminData();

  return <AdminClient initial={data} isDefaultPassword={!process.env.ADMIN_PASSWORD} />;
}

import { redirect } from "next/navigation";
import DashboardClient from "@/components/DashboardClient";
import { getDashboard } from "@/lib/data";
import { getAuthUser } from "@/lib/session";

export const dynamic = "force-dynamic";

export default async function DashboardPage() {
  const user = await getAuthUser();

  if (!user) redirect("/login");
  if (user.role === "admin") redirect("/admin");
  if (!user.participantId) redirect("/login");

  const payload = await getDashboard(user.participantId);

  if (!payload) {
    redirect("/login");
  }

  return <DashboardClient initial={payload} />;
}

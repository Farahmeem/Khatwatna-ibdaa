import { asc } from "drizzle-orm";
import { redirect } from "next/navigation";
import Link from "next/link";
import { db } from "@/db";
import { participants } from "@/db/schema";
import LoginForm from "@/components/LoginForm";
import { getAuthUser } from "@/lib/session";

export const dynamic = "force-dynamic";

export default async function LoginPage() {
  const user = await getAuthUser();
  if (user?.role === "participant") redirect("/dashboard");
  if (user?.role === "admin") redirect("/admin");

  let people: { name: string }[] = [];
  try {
    people = await db
      .select({ name: participants.name })
      .from(participants)
      .orderBy(asc(participants.createdAt));
  } catch {
    people = [];
  }

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:py-16">
      <div className="grid items-stretch gap-6 lg:grid-cols-[1.05fr_0.95fr]">
        <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-brand-700 via-brand-600 to-brand-800 p-7 text-white shadow-2xl shadow-brand-900/25 sm:p-10">
          <div className="pattern-dots absolute inset-0 opacity-20" />
          <div className="absolute -left-10 -top-10 h-40 w-40 rounded-full bg-gold-300/20 blur-2xl" />
          <div className="absolute bottom-0 right-0 h-52 w-52 rounded-full bg-brand-300/20 blur-3xl" />

          <div className="relative">
            <span className="chip border-white/30 bg-white/15 text-white">✨ بوابة المشاركات</span>
            <h1 className="mt-4 text-3xl font-extrabold leading-snug sm:text-4xl">
              أهلاً بكِ في تحدّي
              <br />
              خطواتنا إبداع
            </h1>
            <p className="mt-3 max-w-md text-sm leading-7 text-brand-50/90">
              ملفكِ الشخصي يحفظ خطواتكِ ونقاطكِ المعرفية بشكل منفصل تماماً عن بقية المشاركات،
              وتظهر نتائجكِ للمشرفة وجميع المشاركات بشكل مباشر.
            </p>

            <ul className="mt-7 space-y-3 text-sm">
              {[
                { icon: "👟", text: "سجّلي خطواتكِ اليومية وعدّليها قبل الاعتماد" },
                { icon: "🧠", text: "سؤال معرفي جديد كل يوم + 10 نقاط لكل إجابة صحيحة" },
                { icon: "📊", text: "شريط تقدم أسبوعي ونسبة إنجاز محسوبة تلقائياً" },
                { icon: "🏆", text: "لوحة متصدرات مباشرة للخطوات وللنقاط المعرفية" },
              ].map((item) => (
                <li
                  key={item.text}
                  className="flex items-start gap-3 rounded-2xl border border-white/15 bg-white/10 px-4 py-3 backdrop-blur-sm"
                >
                  <span className="grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-white/15">
                    {item.icon}
                  </span>
                  <span className="leading-6 text-brand-50">{item.text}</span>
                </li>
              ))}
            </ul>

            <div className="mt-7 rounded-2xl border border-gold-200/40 bg-gold-300/15 px-4 py-3 text-xs font-bold leading-6 text-gold-50">
              الهدف اليومي: 10,000 خطوة · الهدف الأسبوعي: 70,000 خطوة · مدة التحدي: 7 أيام
            </div>

            <Link
              href="/leaderboard"
              className="mt-6 inline-flex items-center gap-2 text-sm font-bold text-white/90 underline-offset-4 hover:underline"
            >
              تصفّحي لوحة المتصدرات قبل الدخول ←
            </Link>
          </div>
        </section>

        <section className="flex flex-col justify-center">
          <LoginForm
            existingNames={people.map((person) => person.name)}
            isAdminPasswordDefault={!process.env.ADMIN_PASSWORD}
          />
          <p className="mt-4 rounded-2xl border border-brand-100 bg-white/80 px-4 py-3 text-center text-xs leading-6 text-ink-500">
            🔐 لكل مشاركة جلسة خاصة ومعرّف مستقل. المشرفة تملك صلاحيات إدارة المشاركات والنتائج.
          </p>
        </section>
      </div>
    </div>
  );
}

import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import SiteHeader from "@/components/SiteHeader";

export const metadata: Metadata = {
  title: "خطواتنا إبداع | تحدي المشي الأسبوعي المدمج بالمعرفة",
  description:
    "منصة تفاعلية للتحدي الأسبوعي للمشي مع منافسات معرفية يومية في الرياضيات واللغة العربية والإنجليزية.",
};

export const viewport: Viewport = {
  themeColor: "#0a7253",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;700;800;900&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="min-h-screen antialiased">
        <div className="flex min-h-screen flex-col">
          <SiteHeader />
          <main className="flex-1">{children}</main>
          <footer className="mt-16 border-t border-brand-100 bg-white/70 py-8">
            <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-3 px-4 text-center text-sm text-ink-500 sm:flex-row sm:text-right">
              <div>
                <p className="font-extrabold text-brand-800">
                  خطواتنا إبداع <span className="text-gold-500">✦</span> خطوة اليوم.. إنجاز الغد
                </p>
                <p className="mt-1 text-xs">
                  تحدي المشي الأسبوعي المدمج بالمعرفة — 7 أيام، 70,000 خطوة، ومعرفة تنمو مع كل خطوة.
                </p>
              </div>
              <p className="text-xs text-ink-500/80">
                صُمم بحبّ ليكون مساحة صحية ومعرفية للجميع 🌿
              </p>
            </div>
          </footer>
        </div>
      </body>
    </html>
  );
}

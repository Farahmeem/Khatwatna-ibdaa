import LeaderboardClient from "@/components/LeaderboardClient";
import { getLeaderboardData } from "@/lib/data";
import { getAuthUser } from "@/lib/session";

export const dynamic = "force-dynamic";

export default async function LeaderboardPage() {
  const [payload, user] = await Promise.all([getLeaderboardData(), getAuthUser()]);

  return (
    <LeaderboardClient
      initial={payload}
      currentParticipantId={user?.role === "participant" ? user.participantId : null}
    />
  );
}

import Image from "next/image";
import Link from "next/link";
import { ProgressBar } from "@/components/ui";
import {
  DAILY_GOAL,
  DOMAIN_ICONS,
  DOMAIN_LABELS,
  MEDALS,
  WEEKLY_GOAL,
} from "@/lib/constants";
import { HOW_IT_WORKS } from "@/lib/content";
import { getLeaderboardData } from "@/lib/data";
import { formatNumber, formatPercent } from "@/lib/format";
import { getQuestionForDay } from "@/lib/questions";
import { getAuthUser } from "@/lib/session";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const [leaderboard, user] = await Promise.all([getLeaderboardData(), getAuthUser()]);
  const top3 = leaderboard.rows.slice(0, 3);
  const startHref =
    user?.role === "participant" ? "/dashboard" : user?.role === "admin" ? "/admin" : "/login";
  const achievementsHref = user?.role === "participant" ? "/achievements" : "/login";
  const sampleQuestions = [0, 1, 2].map((dayIndex) =>
    getQuestionForDay(leaderboard.week.weekNumber || 1, dayIndex),
  );

  return (
    <div className="mx-auto max-w-6xl px-4 pb-4 pt-6 sm:pt-10">
      {/* الواجهة الرئيسية */}
      <section className="card relative overflow-hidden">
        <div className="pattern-dots absolute inset-0 opacity-30" />
        <div className="relative grid items-center gap-6 p-5 sm:p-8 lg:grid-cols-[1.05fr_0.95fr] lg:p-10">
          <div>
            <span className="chip chip-gold">🎉 تحدي المشي الأسبوعي المدمج بالمعرفة</span>
            <h1 className="mt-4 text-4xl font-extrabold leading-tight text-brand-900 sm:text-5xl">
              خطوة اليوم..
              <br />
              <span className="bg-gradient-to-l from-brand-600 via-brand-500 to-gold-400 bg-clip-text text-transparent">
                إنجاز الغد
              </span>
            </h1>
            <p className="mt-4 max-w-xl text-sm leading-7 text-ink-500 sm:text-base">
              خطواتنا إبداع، لأن كل خطوة تقربنا من هدف، وكل معلومة تضيف إلى عقولنا إبداعاً. منصة
              تفاعلية حقيقية تجمع تحدي المشي الأسبوعي بالمنافسات المعرفية في مكان واحد.
            </p>

            <div className="mt-6 flex flex-wrap gap-2.5">
              <Link href={startHref} className="btn btn-primary">
                👟 ابدئي التحدي
              </Link>
              <Link href="/leaderboard" className="btn btn-gold">
                🏆 لوحة المتصدرات
              </Link>
              <Link href={achievementsHref} className="btn btn-outline">
                🏅 إنجازاتي
              </Link>
            </div>

            <div className="mt-7 grid grid-cols-2 gap-2.5 sm:grid-cols-4">
              {[
                { label: "مدة التحدي", value: "7 أيام", icon: "📅" },
                { label: "الهدف اليومي", value: formatNumber(DAILY_GOAL), icon: "🎯" },
                { label: "الهدف الأسبوعي", value: formatNumber(WEEKLY_GOAL), icon: "🏁" },
                { label: "نقاط السؤال", value: "+10", icon: "🧠" },
              ].map((item) => (
                <div
                  key={item.label}
                  className="rounded-2xl border border-brand-100 bg-white/90 px-3 py-2.5 text-center shadow-sm"
                >
                  <p className="text-[10px] font-bold text-ink-500">
                    {item.icon} {item.label}
                  </p>
                  <p className="text-base font-extrabold text-brand-900">{item.value}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="relative">
            <div className="relative overflow-hidden rounded-3xl border border-brand-100 shadow-xl shadow-brand-900/10">
              <Image
                src="/images/hero.png"
                alt="نساء يمشين ضمن تحدي خطواتنا إبداع"
                width={900}
                height={700}
                priority
                className="h-64 w-full object-cover sm:h-80 lg:h-[22rem]"
              />
            </div>
            <div className="absolute -bottom-4 right-4 animate-floaty rounded-2xl border border-brand-100 bg-white px-3 py-2 shadow-lg">
              <p className="text-[10px] font-bold text-ink-500">🌟 هدف اليوم</p>
              <p className="text-sm font-extrabold text-brand-800">10,000 خطوة</p>
            </div>
            <div className="absolute -top-3 left-3 rounded-2xl border border-gold-200 bg-gold-50 px-3 py-2 shadow-lg">
              <p className="text-[10px] font-bold text-gold-600">🏆 إجمالي الخطوات</p>
              <p className="text-sm font-extrabold text-brand-900">
                {formatNumber(leaderboard.totals.steps)}
              </p>
            </div>
          </div>
        </div>

        <div className="relative grid grid-cols-2 gap-px border-t border-brand-100 bg-brand-100/60 sm:grid-cols-4">
          {[
            { label: "مشاركات", value: formatNumber(leaderboard.totals.participants), icon: "👥" },
            { label: "خطوة جماعية", value: formatNumber(leaderboard.totals.steps), icon: "👟" },
            { label: "كيلومترات", value: formatNumber(leaderboard.totals.km), icon: "📍" },
            { label: "نقاط معرفية", value: formatNumber(leaderboard.totals.points), icon: "🧠" },
          ].map((item) => (
            <div key={item.label} className="bg-white/90 px-3 py-3 text-center">
              <p className="text-[10px] font-bold text-ink-500">
                {item.icon} {item.label}
              </p>
              <p className="text-lg font-extrabold text-brand-900">{item.value}</p>
            </div>
          ))}
        </div>
      </section>

      {/* كيف يعمل */}
      <section className="mt-10">
        <div className="mb-5 text-center">
          <span className="chip chip-gold">✨ أربع خطوات للتألق</span>
          <h2 className="mt-2 text-2xl font-extrabold text-brand-900 sm:text-3xl">
            رحلة أسبوع واحد تصنع فرقاً كبيراً
          </h2>
        </div>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {HOW_IT_WORKS.map((item, index) => (
            <div key={item.title} className="card p-5">
              <div className="flex items-center justify-between">
                <span className="grid h-11 w-11 place-items-center rounded-2xl bg-brand-50 text-xl">
                  {item.icon}
                </span>
                <span className="text-2xl font-extrabold text-brand-100">{index + 1}</span>
              </div>
              <h3 className="mt-3 text-base font-extrabold text-brand-900">{item.title}</h3>
              <p className="mt-1 text-xs leading-6 text-ink-500">{item.text}</p>
            </div>
          ))}
        </div>
      </section>

      {/* المجالات المعرفية */}
      <section className="mt-10 rounded-3xl border border-brand-100 bg-white/80 p-5 sm:p-7">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <span className="chip">🧠 سؤال كل يوم</span>
            <h2 className="mt-2 text-2xl font-extrabold text-brand-900">
              المعرفة تمشي معكِ خطوة بخطوة
            </h2>
            <p className="mt-1 max-w-2xl text-sm text-ink-500">
              سؤال جديد كل يوم بالتناوب بين الرياضيات واللغة العربية واللغة الإنجليزية، مع نتيجة
              فورية وتفسير مبسط و10 نقاط لكل إجابة صحيحة.
            </p>
          </div>
          <span className="chip chip-gold">🎁 7 أسئلة في الأسبوع = 70 نقطة ممكنة</span>
        </div>

        <div className="mt-5 grid gap-3 lg:grid-cols-3">
          {sampleQuestions.map((question) => (
            <div key={question.id} className="rounded-2xl border border-brand-100 bg-brand-50/40 p-4">
              <span className="chip">
                {DOMAIN_ICONS[question.domain]} {DOMAIN_LABELS[question.domain]}
              </span>
              <p className="mt-2 text-sm font-bold leading-6 text-ink-700">{question.prompt}</p>
              <ul className="mt-2 space-y-1">
                {question.options.slice(0, 2).map((option) => (
                  <li
                    key={option}
                    className="rounded-lg border border-white bg-white px-2.5 py-1 text-[11px] font-bold text-ink-500"
                  >
                    {option}
                  </li>
                ))}
              </ul>
              <p className="mt-2 text-[10px] font-bold text-brand-700">
                … وخياران آخران داخل التحدي ✨
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* لوحة المتصدرات المختصرة */}
      <section className="mt-10 grid gap-4 lg:grid-cols-[1.15fr_0.85fr]">
        <div className="card p-5">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <span className="chip">🏁 مباشرة الآن</span>
              <h2 className="mt-1 text-xl font-extrabold text-brand-900">منصة التتويج</h2>
            </div>
            <Link href="/leaderboard" className="btn btn-soft !py-1.5 !text-xs">
              الترتيب الكامل ←
            </Link>
          </div>

          {top3.length === 0 ? (
            <div className="mt-4 rounded-2xl bg-brand-50/60 px-4 py-10 text-center">
              <p className="text-3xl">🌱</p>
              <p className="mt-2 text-sm font-extrabold text-brand-900">
                السباق لم يبدأ بعد… كوني أول المتصدرات!
              </p>
              <Link href={startHref} className="btn btn-primary mt-3 !py-2 !text-xs">
                ابدئي التحدي
              </Link>
            </div>
          ) : (
            <div className="mt-4 space-y-2">
              {top3.map((row) => (
                <div
                  key={row.id}
                  className="flex items-center justify-between gap-2 rounded-2xl border border-brand-100 bg-white px-3 py-2.5"
                >
                  <div className="flex items-center gap-2">
                    <span className="text-2xl">{MEDALS[row.rankSteps - 1] ?? "🎖️"}</span>
                    <span className="grid h-9 w-9 place-items-center rounded-full bg-brand-50 text-base">
                      {row.avatar}
                    </span>
                    <div>
                      <p className="text-sm font-extrabold text-brand-900">{row.name}</p>
                      <p className="text-[10px] font-medium text-ink-500">
                        {formatNumber(row.km)} كم · {row.points} نقطة معرفية
                      </p>
                    </div>
                  </div>
                  <div className="w-24">
                    <ProgressBar value={row.percent} height="h-1.5" />
                    <p className="mt-1 text-left text-[10px] font-bold text-brand-700">
                      {formatPercent(row.percent)}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="space-y-3">
          <div className="rounded-3xl bg-gradient-to-br from-brand-700 to-brand-900 p-5 text-white shadow-xl">
            <p className="text-xs font-bold text-brand-100">رسالة اليوم</p>
            <p dir="ltr" className="mt-2 rounded-2xl bg-white/10 px-3 py-2 text-sm font-extrabold">
              Every step counts. Keep moving forward!
            </p>
            <p className="mt-1 text-xs font-medium text-brand-50">
              الترجمة: كل خطوة لها قيمة… واصلي التقدم للأمام!
            </p>
            <div className="mt-3 rounded-2xl bg-white/10 px-3 py-2 text-xs font-bold leading-6">
              «بداية الغيث قطرة، وأول المجد خطوة؛ امضي فإن العزيمة تصنع المستحيل.»
            </div>
            <div className="mt-2 rounded-2xl bg-gold-300/20 px-3 py-2 text-xs font-bold text-gold-50">
              هل تعلمين أن 10,000 خطوة تعادل تقريباً 7.5 كم؟
            </div>
          </div>

          <div className="card p-5">
            <p className="text-sm font-extrabold text-brand-900">🌿 لماذا خطواتنا إبداع؟</p>
            <ul className="mt-2 space-y-1.5 text-xs leading-6 text-ink-500">
              <li>• بيانات حقيقية محفوظة في قاعدة بيانات، لا تختفي عند التحديث.</li>
              <li>• ملف مستقل لكل مشاركة بخطواتها ونقاطها دون اختلاط.</li>
              <li>• متابعة مباشرة للنتائج مع لوحة متصدرات تتحدث تلقائياً.</li>
              <li>• لوحة مشرفة لإدارة المشاركات والنتائج وتصدير التقارير.</li>
            </ul>
          </div>
        </div>
      </section>

      {/* دعوة للتسجيل */}
      <section className="mt-10 overflow-hidden rounded-3xl bg-gradient-to-l from-brand-600 via-brand-600 to-brand-800 p-6 text-center text-white shadow-2xl sm:p-10">
        <p className="text-xs font-bold text-brand-100">جاهزة للبدء؟</p>
        <h2 className="mt-2 text-2xl font-extrabold sm:text-3xl">
          سجّلي اسمكِ… وابدئي أول خطوة نحو إنجازكِ
        </h2>
        <p className="mx-auto mt-2 max-w-2xl text-sm leading-7 text-brand-50/90">
          منصة واحدة تجمع كل المشاركات برابط مشترك، ولكل مشاركة ملفها الخاص. تحدّي أسبوع كامل من
          الصحة والمعرفة والمنافسة الشريفة.
        </p>
        <div className="mt-5 flex flex-wrap justify-center gap-2.5">
          <Link href={startHref} className="btn btn-gold">
            👟 ابدئي التحدي الآن
          </Link>
          <Link href="/leaderboard" className="btn !bg-white/15 !text-white">
            🏆 شاهد النتائج
          </Link>
        </div>
      </section>
    </div>
  );
}
